# Razorpay/Stripe client placeholder
