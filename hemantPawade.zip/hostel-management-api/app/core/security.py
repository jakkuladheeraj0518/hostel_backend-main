from datetime import datetime, timedelta, timezone
from typing import Any, Dict
import bcrypt
import jwt
from fastapi import HTTPException, status
from app.core.config import settings

def hash_password(p: str) -> str:
    # Truncate password to 72 bytes for bcrypt compatibility
    password_bytes = p.encode('utf-8')[:72]
    salt = bcrypt.gensalt()
    hashed = bcrypt.hashpw(password_bytes, salt)
    return hashed.decode('utf-8')

def verify_password(p: str, hashed: str) -> bool:
    password_bytes = p.encode('utf-8')[:72]
    hashed_bytes = hashed.encode('utf-8')
    return bcrypt.checkpw(password_bytes, hashed_bytes)

def create_access_token(sub: Dict[str, Any], minutes: int | None = None) -> str:
    expire = datetime.now(timezone.utc) + timedelta(minutes=minutes or settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    payload = {"exp": expire, "user_data": sub}  # Changed from "sub" to "user_data"
    return jwt.encode(payload, settings.SECRET_KEY, algorithm="HS256")

def decode_token(token: str) -> dict:
    try:
        return jwt.decode(token, settings.SECRET_KEY, algorithms=["HS256"])
    except jwt.PyJWTError:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or expired token")
