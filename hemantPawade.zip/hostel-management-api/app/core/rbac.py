from enum import StrEnum

class Role(StrEnum):
    SUPER_ADMIN = "SUPER_ADMIN"
    ADMIN = "ADMIN"
    SUPERVISOR = "SUPERVISOR"
    STUDENT = "STUDENT"
    VISITOR = "VISITOR"
