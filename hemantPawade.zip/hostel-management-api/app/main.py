from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import Response, JSONResponse
from slowapi import _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from app.core.config import settings
from app.core.rate_limiter import limiter, rate_limit_exceeded_handler
from app.api.v1.auth.routes import router as auth_router
from app.api.v1.super_admin.routes import router as super_admin_router
from app.api.v1.admin.routes import router as admin_router
from app.api.v1.supervisor.routes import router as supervisor_router
from app.api.v1.student.routes import router as student_router
from app.api.v1.visitor.routes import router as visitor_router

app = FastAPI(
    title=settings.APP_NAME, 
    version="1.0.0",
    description="Hostel Management System API with comprehensive security and validation"
)

# Add rate limiting state
app.state.limiter = limiter

# Add rate limit exceeded handler
app.add_exception_handler(RateLimitExceeded, rate_limit_exceeded_handler)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
async def root():
    return {"message": "Welcome to the Maintenance System API", "docs": "/docs"}

app.include_router(auth_router)
app.include_router(super_admin_router)
app.include_router(admin_router)
app.include_router(supervisor_router)
app.include_router(student_router)
app.include_router(visitor_router)

@app.get("/favicon.ico", include_in_schema=False)
async def favicon():
    return Response(status_code=204)
