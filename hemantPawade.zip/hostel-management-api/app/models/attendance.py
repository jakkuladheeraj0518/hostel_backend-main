from sqlalchemy.orm import Mapped, mapped_column
from sqlalchemy import ForeignKey, String, Date, UniqueConstraint
from datetime import date
from app.models import Base

class Attendance(Base):
    __tablename__ = "attendance"
    id: Mapped[int] = mapped_column(primary_key=True)
    hostel_id: Mapped[int] = mapped_column(ForeignKey("hostels.id", ondelete="CASCADE"), index=True)
    student_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"))
    date: Mapped[date] = mapped_column(Date, index=True)
    status: Mapped[str] = mapped_column(String(16))
    __table_args__ = (UniqueConstraint("hostel_id","student_id","date"),)