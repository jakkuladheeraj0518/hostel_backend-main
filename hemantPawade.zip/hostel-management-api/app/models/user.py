from sqlalchemy.orm import Mapped, mapped_column, validates
from sqlalchemy import String, Boolean, Date, ForeignKey
from datetime import date
from app.models import Base
import re

class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(primary_key=True)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    full_name: Mapped[str] = mapped_column(String(255))
    role: Mapped[str] = mapped_column(String(32), default="VISITOR")
    hashed_password: Mapped[str] = mapped_column(String(255))
    is_active: Mapped[bool] = mapped_column(default=True)
    
    # Additional fields from diagrams
    phone: Mapped[str | None] = mapped_column(String(32))
    hostel_id: Mapped[int | None] = mapped_column(ForeignKey("hostels.id"))
    room_number: Mapped[str | None] = mapped_column(String(32))
    bed_number: Mapped[str | None] = mapped_column(String(32))
    check_in_date: Mapped[date | None] = mapped_column(Date)
    
    # Student-specific fields
    student_id: Mapped[str | None] = mapped_column(String(32))
    hostel_code: Mapped[str | None] = mapped_column(String(32))
    blood_group: Mapped[str | None] = mapped_column(String(8))
    guardian_name: Mapped[str | None] = mapped_column(String(255))
    guardian_phone: Mapped[str | None] = mapped_column(String(32))
    emergency_contact: Mapped[str | None] = mapped_column(String(32))
    date_of_birth: Mapped[date | None] = mapped_column(Date)
    
    # Status
    status: Mapped[str] = mapped_column(String(32), default="ACTIVE")
    
    @validates('phone', 'guardian_phone', 'emergency_contact')
    def validate_phone_number(self, key, phone):
        """Validate phone number format"""
        if phone is None:
            return phone
        
        # Remove spaces, dashes, and parentheses
        cleaned = re.sub(r'[\s\-\(\)]', '', phone)
        
        # Check if it matches international format (+1234567890) or local format (1234567890)
        if not re.match(r'^\+?[1-9]\d{9,14}$', cleaned):
            raise ValueError(f'{key} must be a valid phone number (10-15 digits, optional + prefix)')
        
        return phone
    
    @validates('blood_group')
    def validate_blood_group(self, key, blood_group):
        """Validate blood group"""
        if blood_group is None:
            return blood_group
        
        valid_blood_groups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-']
        if blood_group.upper() not in valid_blood_groups:
            raise ValueError(f'blood_group must be one of: {", ".join(valid_blood_groups)}')
        
        return blood_group.upper()
