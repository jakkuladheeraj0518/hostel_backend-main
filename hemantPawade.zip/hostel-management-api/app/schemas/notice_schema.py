from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime

class NoticeCreate(BaseModel):
    title: str = Field(..., min_length=5, max_length=200, description="Notice title")
    content: str = Field(..., min_length=10, max_length=2000, description="Notice content")
    audience: str = Field("ALL", description="Target audience: ALL, STUDENTS, STAFF, PUBLIC")

class NoticeUpdate(BaseModel):
    title: Optional[str] = Field(None, min_length=5, max_length=200, description="Notice title")
    content: Optional[str] = Field(None, min_length=10, max_length=2000, description="Notice content")
    audience: Optional[str] = Field(None, description="Target audience: ALL, STUDENTS, STAFF, PUBLIC")

class NoticeOut(BaseModel):
    id: int
    hostel_id: int
    title: str
    content: str
    audience: str
    created_at: datetime
    updated_at: datetime