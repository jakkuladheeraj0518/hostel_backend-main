from pydantic import BaseModel
from typing import Optional

class HostelCreate(BaseModel):
    name: str

class HostelOut(BaseModel):
    id: int
    name: str

class HostelAssignment(BaseModel):
    admin_id: int
    hostel_id: int

class SupervisorAssignment(BaseModel):
    user_id: int
    hostel_id: int