from pydantic import BaseModel
from typing import Optional

class ComplaintCreate(BaseModel):
    category: str
    description: str
    priority: str = "MEDIUM"

class ComplaintOut(BaseModel):
    id: int
    hostel_id: int
    student_id: int
    category: str
    priority: str
    description: str
    status: str