from pydantic import BaseModel, EmailStr, Field, validator
from app.core.rbac import Role
import re

class UserCreate(BaseModel):
    email: EmailStr
    full_name: str = Field(..., min_length=2, max_length=255, description="Full name of the user")
    password: str = Field(..., min_length=8, max_length=128, description="Password must be 8-128 characters")
    role: Role = Field(..., description="User role must be one of: SUPER_ADMIN, ADMIN, SUPERVISOR, STUDENT, VISITOR")
    
    @validator('role', pre=True)
    def normalize_role(cls, v):
        """Convert role to uppercase to allow case-insensitive input"""
        if isinstance(v, str):
            return v.upper()
        return v
    
    @validator('password')
    def validate_password_strength(cls, v):
        """
        Validate password strength:
        - At least 8 characters
        - At least one uppercase letter
        - At least one lowercase letter
        - At least one digit
        - At least one special character
        """
        if len(v) < 8:
            raise ValueError('Password must be at least 8 characters long')
        
        if not any(c.isupper() for c in v):
            raise ValueError('Password must contain at least one uppercase letter')
        
        if not any(c.islower() for c in v):
            raise ValueError('Password must contain at least one lowercase letter')
        
        if not any(c.isdigit() for c in v):
            raise ValueError('Password must contain at least one digit')
        
        if not any(c in '!@#$%^&*()_+-=[]{}|;:,.<>?/~`' for c in v):
            raise ValueError('Password must contain at least one special character (!@#$%^&*()_+-=[]{}|;:,.<>?/~`)')
        
        # Check for common weak passwords
        weak_passwords = ['password', '12345678', 'qwerty123', 'admin123', 'welcome123']
        if v.lower() in weak_passwords:
            raise ValueError('Password is too common. Please choose a stronger password')
        
        return v
    
    @validator('full_name')
    def validate_full_name(cls, v):
        """Validate full name contains only letters, spaces, and common punctuation"""
        if not re.match(r'^[a-zA-Z\s\.\-\']+$', v):
            raise ValueError('Full name can only contain letters, spaces, dots, hyphens, and apostrophes')
        return v.strip()

class UserOut(BaseModel):
    id: int
    email: EmailStr
    full_name: str
    role: str
