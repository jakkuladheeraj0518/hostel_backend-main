from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import date

class AttendanceMark(BaseModel):
    student_id: int
    day: date
    status: str = Field(..., description="PRESENT, ABSENT, LATE")

class AttendanceCreate(BaseModel):
    hostel_id: int
    date: date
    attendance: List[AttendanceMark]

class AttendanceOut(BaseModel):
    id: int
    hostel_id: int
    student_id: int
    date: date
    status: str

class AttendanceReport(BaseModel):
    student_id: int
    total_days: int
    present_days: int
    absent_days: int
    late_days: int
    attendance_percentage: float