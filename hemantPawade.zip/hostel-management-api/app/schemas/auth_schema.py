from pydantic import BaseModel, EmailStr, Field

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_in: int = Field(default=3600, description="Token expiration time in seconds")

class RefreshToken(BaseModel):
    refresh_token: str

class LoginIn(BaseModel):
    email: EmailStr = Field(..., description="User email address")
    password: str = Field(..., min_length=1, description="User password")
