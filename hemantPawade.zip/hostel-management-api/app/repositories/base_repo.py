# Base repository helpers
