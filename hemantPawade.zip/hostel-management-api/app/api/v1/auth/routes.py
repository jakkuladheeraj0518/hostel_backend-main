from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.core.security import verify_password, hash_password, create_access_token
from app.core.rate_limiter import limiter
from app.core.audit_logger import AuditLogger, AuditAction, get_client_ip, get_user_agent
from app.schemas.auth_schema import Token, LoginIn
from app.schemas.user_schema import UserCreate
from app.models.user import User
import logging

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/auth", tags=["Auth"])

@router.post("/login", response_model=Token)
@limiter.limit("5/minute")  # Rate limit: 5 login attempts per minute
def login(request: Request, data: LoginIn, db: Session = Depends(get_db)):
    """
    User login with rate limiting and audit logging
    - Rate limited to 5 attempts per minute per IP
    - All login attempts are logged for security auditing
    """
    ip_address = get_client_ip(request)
    user_agent = get_user_agent(request)
    
    user = db.query(User).filter(User.email == data.email).one_or_none()
    
    if not user or not verify_password(data.password, user.hashed_password):
        # Audit logging disabled - audit_logs table missing
        raise HTTPException(400, "Invalid credentials")
    
    # Check if user is active
    if not user.is_active:
        # Audit logging disabled - audit_logs table missing
        raise HTTPException(403, "Account is inactive. Please contact administrator.")
    
    # Create access token
    access = create_access_token({
        "id": user.id, 
        "email": user.email, 
        "role": user.role,
        "hostel_id": user.hostel_id
    })
    
    # Log successful login (disabled temporarily - audit_logs table missing)
    # Commenting out to prevent session errors
    # try:
    #     AuditLogger.log_authentication(
    #         db=db,
    #         action=AuditAction.LOGIN_SUCCESS,
    #         email=user.email,
    #         ip_address=ip_address,
    #         user_agent=user_agent,
    #         success=True
    #     )
    # except Exception:
    #     pass
    
    logger.info(f"Successful login: {user.email} from {ip_address}")
    
    return Token(access_token=access, expires_in=3600)

@router.post("/register")
@limiter.limit("3/minute")  # Rate limit: 3 registration attempts per minute
def register(request: Request, user_data: UserCreate, db: Session = Depends(get_db)):
    """
    User registration with rate limiting and validation
    - Rate limited to 3 attempts per minute per IP
    - Password strength validation enforced
    - Role validation enforced
    - Registration logged for audit
    """
    ip_address = get_client_ip(request)
    
    # Check if email already exists
    if db.query(User).filter(User.email == user_data.email).first():
        logger.warning(f"Registration attempt with existing email: {user_data.email} from {ip_address}")
        raise HTTPException(400, "Email already registered")
    
    # Create new user
    new_user = User(
        email=user_data.email,
        full_name=user_data.full_name,
        hashed_password=hash_password(user_data.password),
        role=user_data.role.value  # Convert enum to string
    )
    
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    
    # Audit logging disabled - audit_logs table missing
    # AuditLogger.log(...)
    
    logger.info(f"New user registered: {new_user.email} (Role: {new_user.role}) from {ip_address}")
    
    return {
        "id": new_user.id,
        "email": new_user.email,
        "message": "Registration successful. Please login to continue."
    }
