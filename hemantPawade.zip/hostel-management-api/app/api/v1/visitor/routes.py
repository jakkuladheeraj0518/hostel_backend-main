from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import func, desc
from typing import Optional
from app.core.database import get_db
from app.models.hostel import Hostel
from app.models.review import Review
from app.models.notice import Notice
from app.schemas.review_schema import ReviewCreate

router = APIRouter(prefix="/visitor", tags=["Visitor"])

@router.get("/hostels")
def list_hostels(db: Session = Depends(get_db)):
    hostels = db.query(Hostel).all()
    
    # Get average ratings for each hostel
    hostel_data = []
    for h in hostels:
        avg_rating = db.query(func.avg(Review.rating)).filter(
            Review.hostel_id == h.id, 
            Review.is_approved == True
        ).scalar()
        
        review_count = db.query(func.count(Review.id)).filter(
            Review.hostel_id == h.id, 
            Review.is_approved == True
        ).scalar()
        
        hostel_data.append({
            "id": h.id, 
            "name": h.name,
            "avg_rating": round(avg_rating, 2) if avg_rating else 0,
            "review_count": review_count or 0
        })
    
    return {"hostels": hostel_data}

@router.get("/hostels/{hostel_id}")
def get_hostel_details(hostel_id: int, db: Session = Depends(get_db)):
    hostel = db.query(Hostel).filter(Hostel.id == hostel_id).first()
    if not hostel:
        raise HTTPException(404, "Hostel not found")
    
    # Get hostel statistics
    avg_rating = db.query(func.avg(Review.rating)).filter(
        Review.hostel_id == hostel_id, 
        Review.is_approved == True
    ).scalar()
    
    review_count = db.query(func.count(Review.id)).filter(
        Review.hostel_id == hostel_id, 
        Review.is_approved == True
    ).scalar()
    
    # Get rating distribution
    rating_distribution = {}
    for i in range(1, 6):
        count = db.query(func.count(Review.id)).filter(
            Review.hostel_id == hostel_id,
            Review.rating == i,
            Review.is_approved == True
        ).scalar()
        rating_distribution[f"{i}_star"] = count or 0
    
    return {
        "id": hostel.id,
        "name": hostel.name,
        "avg_rating": round(avg_rating, 2) if avg_rating else 0,
        "review_count": review_count or 0,
        "rating_distribution": rating_distribution
    }

@router.get("/hostels/{hostel_id}/reviews")
def get_hostel_reviews(hostel_id: int, skip: int = 0, limit: int = 20, 
                      sort_by: str = "newest", rating_filter: Optional[int] = None,
                      db: Session = Depends(get_db)):
    query = db.query(Review).filter(
        Review.hostel_id == hostel_id, 
        Review.is_approved == True,
        Review.is_spam == False
    )
    
    # Filter by rating if specified
    if rating_filter:
        query = query.filter(Review.rating == rating_filter)
    
    # Apply sorting
    if sort_by == "newest":
        query = query.order_by(desc(Review.created_at))
    elif sort_by == "oldest":
        query = query.order_by(Review.created_at)
    elif sort_by == "highest_rating":
        query = query.order_by(desc(Review.rating), desc(Review.created_at))
    elif sort_by == "lowest_rating":
        query = query.order_by(Review.rating, desc(Review.created_at))
    elif sort_by == "most_helpful":
        query = query.order_by(desc(Review.helpful_count), desc(Review.created_at))
    
    reviews = query.offset(skip).limit(limit).all()
    
    return {"reviews": [{"id": r.id, "rating": r.rating, "text": r.text, 
                        "photo_url": r.photo_url, "helpful_count": r.helpful_count,
                        "created_at": r.created_at} for r in reviews]}

@router.post("/reviews/{review_id}/helpful")
def mark_review_helpful(review_id: int, db: Session = Depends(get_db)):
    """Allow visitors to mark reviews as helpful"""
    review = db.query(Review).filter(Review.id == review_id).first()
    if not review:
        raise HTTPException(404, "Review not found")
    
    if not review.is_approved or review.is_spam:
        raise HTTPException(400, "Cannot mark this review as helpful")
    
    review.helpful_count += 1
    db.commit()
    return {"ok": True, "helpful_count": review.helpful_count}

@router.get("/reviews/stats")
def get_review_stats(hostel_id: Optional[int] = None, db: Session = Depends(get_db)):
    """Get overall review statistics"""
    query = db.query(Review).filter(Review.is_approved == True, Review.is_spam == False)
    
    if hostel_id:
        query = query.filter(Review.hostel_id == hostel_id)
    
    total_reviews = query.count()
    avg_rating = query.with_entities(func.avg(Review.rating)).scalar() or 0
    
    # Rating distribution
    rating_dist = {}
    for i in range(1, 6):
        count = query.filter(Review.rating == i).count()
        rating_dist[f"{i}_star"] = count
    
    return {
        "total_reviews": total_reviews,
        "avg_rating": round(avg_rating, 2),
        "rating_distribution": rating_dist
    }

@router.post("/reviews/{hostel_id}")
def submit_anonymous_review(hostel_id: int, body: ReviewCreate, db: Session = Depends(get_db)):
    # Allow anonymous reviews from visitors
    hostel = db.query(Hostel).filter(Hostel.id == hostel_id).first()
    if not hostel:
        raise HTTPException(404, "Hostel not found")
    
    review = Review(
        hostel_id=hostel_id, 
        student_id=None,  # Anonymous review
        rating=body.rating, 
        text=body.text, 
        photo_url=body.photo_url,
        is_approved=False  # Requires admin approval
    )
    db.add(review)
    db.commit()
    db.refresh(review)
    return {"id": review.id, "message": "Review submitted for approval"}

@router.get("/hostels/{hostel_id}/notices")
def get_public_notices(hostel_id: int, db: Session = Depends(get_db)):
    # Check if hostel exists
    hostel = db.query(Hostel).filter(Hostel.id == hostel_id).first()
    if not hostel:
        raise HTTPException(404, "Hostel not found")
    
    # Get public notices
    try:
        notices = db.query(Notice).filter(
            Notice.hostel_id == hostel_id,
            Notice.audience.in_(["ALL", "PUBLIC"])
        ).all()
        
        return {"notices": [{"id": n.id, "title": n.title, "content": n.content, "created_at": n.created_at} for n in notices]}
    except Exception as e:
        # If there's an error, return empty list
        return {"notices": []}

@router.get("/search/hostels")
def search_hostels(q: Optional[str] = None, min_rating: Optional[float] = None, 
                  max_rating: Optional[float] = None, sort_by: str = "rating",
                  db: Session = Depends(get_db)):
    query = db.query(Hostel)
    
    if q:
        query = query.filter(Hostel.name.ilike(f"%{q}%"))
    
    hostels = query.all()
    
    # Filter and sort by rating
    hostel_data = []
    for h in hostels:
        avg_rating = db.query(func.avg(Review.rating)).filter(
            Review.hostel_id == h.id, 
            Review.is_approved == True,
            Review.is_spam == False
        ).scalar()
        
        avg_rating = avg_rating or 0
        
        # Apply rating filters
        if min_rating is not None and avg_rating < min_rating:
            continue
        if max_rating is not None and avg_rating > max_rating:
            continue
        
        review_count = db.query(func.count(Review.id)).filter(
            Review.hostel_id == h.id, 
            Review.is_approved == True,
            Review.is_spam == False
        ).scalar()
        
        hostel_data.append({
            "id": h.id, 
            "name": h.name,
            "avg_rating": round(avg_rating, 2),
            "review_count": review_count or 0
        })
    
    # Sort results
    if sort_by == "rating":
        hostel_data.sort(key=lambda x: x["avg_rating"], reverse=True)
    elif sort_by == "reviews":
        hostel_data.sort(key=lambda x: x["review_count"], reverse=True)
    elif sort_by == "name":
        hostel_data.sort(key=lambda x: x["name"])
    
    return {"hostels": hostel_data}

@router.get("/reviews/trending")
def get_trending_reviews(limit: int = 10, days: int = 7, db: Session = Depends(get_db)):
    """Get trending reviews based on helpful votes and recency"""
    from datetime import datetime, timedelta
    
    start_date = datetime.now() - timedelta(days=days)
    
    reviews = db.query(Review).filter(
        Review.is_approved == True,
        Review.is_spam == False,
        Review.created_at >= start_date,
        Review.helpful_count > 0
    ).order_by(
        desc(Review.helpful_count),
        desc(Review.created_at)
    ).limit(limit).all()
    
    return {"trending_reviews": [
        {
            "id": r.id,
            "hostel_id": r.hostel_id,
            "rating": r.rating,
            "text": r.text[:200] + "..." if len(r.text) > 200 else r.text,
            "helpful_count": r.helpful_count,
            "created_at": r.created_at
        } for r in reviews
    ]}

@router.get("/reviews/summary")
def get_reviews_summary(hostel_id: Optional[int] = None, db: Session = Depends(get_db)):
    """Get comprehensive review summary with insights"""
    query = db.query(Review).filter(
        Review.is_approved == True,
        Review.is_spam == False
    )
    
    if hostel_id:
        query = query.filter(Review.hostel_id == hostel_id)
    
    total_reviews = query.count()
    
    if total_reviews == 0:
        return {"message": "No reviews found", "total_reviews": 0}
    
    avg_rating = query.with_entities(func.avg(Review.rating)).scalar()
    
    # Rating distribution
    rating_dist = {}
    for i in range(1, 6):
        count = query.filter(Review.rating == i).count()
        rating_dist[f"{i}_star"] = {
            "count": count,
            "percentage": round((count / total_reviews) * 100, 1)
        }
    
    # Recent trends (last 30 days vs previous 30 days)
    from datetime import datetime, timedelta
    now = datetime.now()
    last_30_days = now - timedelta(days=30)
    previous_30_days = now - timedelta(days=60)
    
    recent_reviews = query.filter(Review.created_at >= last_30_days).count()
    previous_reviews = query.filter(
        Review.created_at >= previous_30_days,
        Review.created_at < last_30_days
    ).count()
    
    trend = "stable"
    if recent_reviews > previous_reviews * 1.2:
        trend = "increasing"
    elif recent_reviews < previous_reviews * 0.8:
        trend = "decreasing"
    
    # Most helpful reviews
    top_reviews = query.filter(Review.helpful_count > 0).order_by(
        desc(Review.helpful_count)
    ).limit(3).all()
    
    return {
        "total_reviews": total_reviews,
        "avg_rating": round(avg_rating, 2),
        "rating_distribution": rating_dist,
        "review_trend": {
            "status": trend,
            "recent_count": recent_reviews,
            "previous_count": previous_reviews
        },
        "top_helpful_reviews": [
            {
                "id": r.id,
                "rating": r.rating,
                "text": r.text[:150] + "..." if len(r.text) > 150 else r.text,
                "helpful_count": r.helpful_count
            } for r in top_reviews
        ]
    }
