from fastapi import APIRouter, Request

router = APIRouter(prefix="/webhooks", tags=["Webhooks"])

@router.post("/payment")
async def payment_webhook(req: Request):
    payload = await req.json()
    # verify signature with gateway here
    return {"received": True}
