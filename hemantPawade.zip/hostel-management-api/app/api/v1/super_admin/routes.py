from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import Optional
from app.core.database import get_db
from app.api.deps import current_user
from app.core.rbac import Role
from app.models.hostel import Hostel, AdminHostel, Supervisor
from app.models.user import User
from app.models.review import Review
from app.models.maintenance import MaintenanceRequest, Complaint
from app.models.leave import LeaveRequest
from app.schemas.user_schema import UserCreate, UserOut
from app.schemas.hostel_schema import HostelCreate, SupervisorAssignment

router = APIRouter(prefix="/super-admin", tags=["Super Admin"])

# Hostel Management
@router.post("/hostels")
def create_hostel(hostel_data: HostelCreate, db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") != Role.SUPER_ADMIN:
        raise HTTPException(403, "Only SUPER_ADMIN can create hostels")
    
    if db.query(Hostel).filter(Hostel.name == hostel_data.name).first():
        raise HTTPException(400, "Hostel already exists")
    
    h = Hostel(name=hostel_data.name)
    db.add(h)
    db.commit()
    db.refresh(h)
    return {"id": h.id, "name": h.name}

@router.get("/hostels")
def get_all_hostels(db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") != Role.SUPER_ADMIN:
        raise HTTPException(403, "Only SUPER_ADMIN can access this")
    
    hostels = db.query(Hostel).all()
    
    # Get statistics for each hostel
    hostel_data = []
    for h in hostels:
        admin_count = db.query(func.count(AdminHostel.id)).filter(AdminHostel.hostel_id == h.id).scalar()
        supervisor_count = db.query(func.count(Supervisor.id)).filter(Supervisor.hostel_id == h.id).scalar()
        review_count = db.query(func.count(Review.id)).filter(Review.hostel_id == h.id).scalar()
        avg_rating = db.query(func.avg(Review.rating)).filter(Review.hostel_id == h.id, Review.is_approved == True).scalar()
        
        hostel_data.append({
            "id": h.id,
            "name": h.name,
            "admin_count": admin_count or 0,
            "supervisor_count": supervisor_count or 0,
            "review_count": review_count or 0,
            "avg_rating": round(avg_rating, 2) if avg_rating else 0
        })
    
    return {"hostels": hostel_data}

@router.put("/hostels/{hostel_id}")
def update_hostel(hostel_id: int, hostel_data: HostelCreate, db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") != Role.SUPER_ADMIN:
        raise HTTPException(403, "Only SUPER_ADMIN can update hostels")
    
    hostel = db.query(Hostel).filter(Hostel.id == hostel_id).first()
    if not hostel:
        raise HTTPException(404, "Hostel not found")
    
    # Check if name already exists (excluding current hostel)
    existing = db.query(Hostel).filter(Hostel.name == hostel_data.name, Hostel.id != hostel_id).first()
    if existing:
        raise HTTPException(400, "Hostel name already exists")
    
    hostel.name = hostel_data.name
    db.commit()
    return {"ok": True}

@router.delete("/hostels/{hostel_id}")
def delete_hostel(hostel_id: int, db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") != Role.SUPER_ADMIN:
        raise HTTPException(403, "Only SUPER_ADMIN can delete hostels")
    
    hostel = db.query(Hostel).filter(Hostel.id == hostel_id).first()
    if not hostel:
        raise HTTPException(404, "Hostel not found")
    
    db.delete(hostel)
    db.commit()
    return {"ok": True}

# User Management
@router.post("/users", response_model=UserOut)
def create_user(user_data: UserCreate, db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") != Role.SUPER_ADMIN:
        raise HTTPException(403, "Only SUPER_ADMIN can create users")
    
    if db.query(User).filter(User.email == user_data.email).first():
        raise HTTPException(400, "Email already registered")
    
    from app.core.security import hash_password
    new_user = User(
        email=user_data.email,
        full_name=user_data.full_name,
        hashed_password=hash_password(user_data.password),
        role=user_data.role
    )
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    return new_user

@router.get("/users")
def get_all_users(role: Optional[str] = None, skip: int = 0, limit: int = 100, 
                 db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") != Role.SUPER_ADMIN:
        raise HTTPException(403, "Only SUPER_ADMIN can access this")
    
    query = db.query(User)
    if role:
        query = query.filter(User.role == role)
    
    users = query.offset(skip).limit(limit).all()
    return {"users": [{"id": u.id, "email": u.email, "full_name": u.full_name, 
                      "role": u.role, "is_active": u.is_active} for u in users]}

@router.put("/users/{user_id}/role")
def update_user_role(user_id: int, new_role: str, db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") != Role.SUPER_ADMIN:
        raise HTTPException(403, "Only SUPER_ADMIN can update user roles")
    
    target_user = db.query(User).filter(User.id == user_id).first()
    if not target_user:
        raise HTTPException(404, "User not found")
    
    target_user.role = new_role
    db.commit()
    return {"ok": True}

@router.delete("/users/{user_id}")
def delete_user(user_id: int, db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") != Role.SUPER_ADMIN:
        raise HTTPException(403, "Only SUPER_ADMIN can delete users")
    
    target_user = db.query(User).filter(User.id == user_id).first()
    if not target_user:
        raise HTTPException(404, "User not found")
    
    db.delete(target_user)
    db.commit()
    return {"ok": True}

# Admin-Hostel Assignment
@router.post("/assign-admin-hostel")
def assign_admin_to_hostel(admin_id: int, hostel_id: int, db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") != Role.SUPER_ADMIN:
        raise HTTPException(403, "Only SUPER_ADMIN can assign admins")
    
    # Check if admin exists and has ADMIN role
    admin = db.query(User).filter(User.id == admin_id, User.role == Role.ADMIN).first()
    if not admin:
        raise HTTPException(404, "Admin not found")
    
    # Check if hostel exists
    hostel = db.query(Hostel).filter(Hostel.id == hostel_id).first()
    if not hostel:
        raise HTTPException(404, "Hostel not found")
    
    # Check if assignment already exists
    existing = db.query(AdminHostel).filter(AdminHostel.admin_id == admin_id, AdminHostel.hostel_id == hostel_id).first()
    if existing:
        raise HTTPException(400, "Admin already assigned to this hostel")
    
    assignment = AdminHostel(admin_id=admin_id, hostel_id=hostel_id)
    db.add(assignment)
    db.commit()
    db.refresh(assignment)
    return {"id": assignment.id}

@router.delete("/admin-hostel/{assignment_id}")
def remove_admin_hostel_assignment(assignment_id: int, db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") != Role.SUPER_ADMIN:
        raise HTTPException(403, "Only SUPER_ADMIN can remove assignments")
    
    assignment = db.query(AdminHostel).filter(AdminHostel.id == assignment_id).first()
    if not assignment:
        raise HTTPException(404, "Assignment not found")
    
    db.delete(assignment)
    db.commit()
    return {"ok": True}

# Supervisor Assignment
@router.post("/assign-supervisor")
def assign_supervisor(assignment: SupervisorAssignment, db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") != Role.SUPER_ADMIN:
        raise HTTPException(403, "Only SUPER_ADMIN can assign supervisors")
    
    # Check if user exists and has SUPERVISOR role
    supervisor_user = db.query(User).filter(User.id == assignment.user_id, User.role == Role.SUPERVISOR).first()
    if not supervisor_user:
        raise HTTPException(404, "Supervisor not found")
    
    # Check if hostel exists
    hostel = db.query(Hostel).filter(Hostel.id == assignment.hostel_id).first()
    if not hostel:
        raise HTTPException(404, "Hostel not found")
    
    # Check if supervisor already assigned
    existing = db.query(Supervisor).filter(Supervisor.user_id == assignment.user_id).first()
    if existing:
        raise HTTPException(400, "Supervisor already assigned to a hostel")
    
    supervisor = Supervisor(user_id=assignment.user_id, hostel_id=assignment.hostel_id)
    db.add(supervisor)
    db.commit()
    db.refresh(supervisor)
    return {"id": supervisor.id}

# System Analytics
@router.get("/analytics/overview")
def get_system_overview(db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") != Role.SUPER_ADMIN:
        raise HTTPException(403, "Only SUPER_ADMIN can access analytics")
    
    total_hostels = db.query(func.count(Hostel.id)).scalar()
    total_users = db.query(func.count(User.id)).scalar()
    total_reviews = db.query(func.count(Review.id)).scalar()
    pending_reviews = db.query(func.count(Review.id)).filter(Review.is_approved == False).scalar()
    total_maintenance_requests = db.query(func.count(MaintenanceRequest.id)).scalar()
    pending_maintenance = db.query(func.count(MaintenanceRequest.id)).filter(MaintenanceRequest.status == "PENDING").scalar()
    total_complaints = db.query(func.count(Complaint.id)).scalar()
    pending_complaints = db.query(func.count(Complaint.id)).filter(Complaint.status == "PENDING").scalar()
    total_leave_requests = db.query(func.count(LeaveRequest.id)).scalar()
    pending_leave_requests = db.query(func.count(LeaveRequest.id)).filter(LeaveRequest.status == "PENDING").scalar()
    
    # User distribution
    user_roles = {}
    for role in [Role.SUPER_ADMIN, Role.ADMIN, Role.SUPERVISOR, Role.STUDENT, Role.VISITOR]:
        count = db.query(func.count(User.id)).filter(User.role == role).scalar()
        user_roles[role.lower()] = count or 0
    
    return {
        "hostels": {
            "total": total_hostels or 0
        },
        "users": {
            "total": total_users or 0,
            "by_role": user_roles
        },
        "reviews": {
            "total": total_reviews or 0,
            "pending": pending_reviews or 0
        },
        "maintenance": {
            "total_requests": total_maintenance_requests or 0,
            "pending_requests": pending_maintenance or 0,
            "total_complaints": total_complaints or 0,
            "pending_complaints": pending_complaints or 0
        },
        "leave_requests": {
            "total": total_leave_requests or 0,
            "pending": pending_leave_requests or 0
        }
    }
