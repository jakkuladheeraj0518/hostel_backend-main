from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import func, desc
from typing import Optional, List
from datetime import date, datetime
from app.core.database import get_db
from app.api.deps import current_user
from app.core.rbac import Role
from app.schemas.attendance_schema import AttendanceMark
from app.schemas.maintenance_schema import MaintenanceCreate, MaintenanceUpdate, MaintenanceTaskCreate, MaintenanceTaskUpdate, MaintenanceCostCreate
from app.models.attendance import Attendance
from app.models.maintenance import MaintenanceRequest, Complaint, MaintenanceTask, MaintenanceCost
from app.models.leave import LeaveRequest
from app.models.user import User

router = APIRouter(prefix="/supervisor", tags=["Supervisor"])

# Attendance Management
@router.post("/attendance/mark")
def mark_attendance(payload: AttendanceMark, db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") not in [Role.SUPERVISOR, Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    # Default to hostel_id 1 if not set in user profile
    hostel_id = user.get("hostel_id") or 1
    
    rec = db.query(Attendance).filter_by(
        hostel_id=hostel_id, 
        student_id=payload.student_id, 
        date=payload.day
    ).one_or_none()
    
    if rec: 
        rec.status = payload.status
    else: 
        db.add(Attendance(
            hostel_id=hostel_id, 
            student_id=payload.student_id, 
            date=payload.day, 
            status=payload.status
        ))
    db.commit()
    return {"ok": True}

@router.get("/attendance")
def get_attendance(db: Session = Depends(get_db), user=Depends(current_user)):
    """Get attendance records for the hostel"""
    if user.get("role") not in [Role.SUPERVISOR, Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    # Default to hostel_id 1 if not set in user profile
    hostel_id = user.get("hostel_id") or 1
    attendance = db.query(Attendance).filter(Attendance.hostel_id == hostel_id).all()
    return {"attendance": [{"id": a.id, "student_id": a.student_id, "date": a.date, "status": a.status} for a in attendance]}

@router.post("/attendance/bulk-mark")
def bulk_mark_attendance(student_ids: List[int], attendance_date: date, status: str, 
                        db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") not in [Role.SUPERVISOR, Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    # Default to hostel_id 1 if not set in user profile
    hostel_id = user.get("hostel_id") or 1
    
    for student_id in student_ids:
        rec = db.query(Attendance).filter_by(
            hostel_id=hostel_id, 
            student_id=student_id, 
            date=attendance_date
        ).one_or_none()
        
        if rec:
            rec.status = status
        else:
            db.add(Attendance(
                hostel_id=hostel_id, 
                student_id=student_id, 
                date=attendance_date, 
                status=status
            ))
    
    db.commit()
    return {"ok": True, "marked_count": len(student_ids)}

@router.get("/attendance/report")
def get_attendance_report(start_date: Optional[date] = None, end_date: Optional[date] = None, 
                         student_id: Optional[int] = None, db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") not in [Role.SUPERVISOR, Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    query = db.query(Attendance).filter(Attendance.hostel_id == user.get("hostel_id"))
    
    if start_date:
        query = query.filter(Attendance.date >= start_date)
    if end_date:
        query = query.filter(Attendance.date <= end_date)
    if student_id:
        query = query.filter(Attendance.student_id == student_id)
    
    attendance = query.all()
    return {"attendance": [{"id": a.id, "student_id": a.student_id, "date": a.date, "status": a.status} for a in attendance]}

@router.get("/students")
def get_hostel_students(db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") not in [Role.SUPERVISOR, Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    # This would need a proper student-hostel relationship model
    # For now, returning all students with STUDENT role
    students = db.query(User).filter(User.role == Role.STUDENT).all()
    return {"students": [{"id": s.id, "email": s.email, "full_name": s.full_name} for s in students]}

# Maintenance Request Management
@router.post("/maintenance/requests")
def create_maintenance_request(request_data: MaintenanceCreate, db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") not in [Role.SUPERVISOR, Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    # Check for high-value requests requiring admin approval
    requires_approval = request_data.est_cost and request_data.est_cost > 1000
    
    # Default to hostel_id 1 if not set in user profile
    hostel_id = user.get("hostel_id") or 1
    
    request = MaintenanceRequest(
        hostel_id=hostel_id,
        created_by_id=user.get("id"),
        category=request_data.category,
        priority=request_data.priority,
        description=request_data.description,
        photo_url=request_data.photo_url,
        est_cost=request_data.est_cost,
        scheduled_date=request_data.scheduled_date,
        approved=not requires_approval  # Auto-approve low-value requests
    )
    db.add(request)
    db.commit()
    db.refresh(request)
    
    message = "Request created and approved" if not requires_approval else "Request created - admin approval required for high-value repair"
    return {"id": request.id, "message": message, "requires_approval": requires_approval}

@router.get("/maintenance/requests")
def get_maintenance_requests(status: Optional[str] = None, category: Optional[str] = None, 
                           priority: Optional[str] = None, skip: int = 0, limit: int = 100,
                           db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") not in [Role.SUPERVISOR, Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    # Default to hostel_id 1 if not set in user profile
    hostel_id = user.get("hostel_id") or 1
    query = db.query(MaintenanceRequest).filter(MaintenanceRequest.hostel_id == hostel_id)
    
    if status:
        query = query.filter(MaintenanceRequest.status == status)
    if category:
        query = query.filter(MaintenanceRequest.category == category)
    if priority:
        query = query.filter(MaintenanceRequest.priority == priority)
    
    requests = query.offset(skip).limit(limit).all()
    return {"requests": [{"id": r.id, "category": r.category, "priority": r.priority, 
                         "status": r.status, "description": r.description, "photo_url": r.photo_url,
                         "est_cost": r.est_cost, "actual_cost": r.actual_cost, "approved": r.approved,
                         "assigned_to_id": r.assigned_to_id, "scheduled_date": r.scheduled_date,
                         "completed_date": r.completed_date, "created_at": r.created_at} for r in requests]}

@router.put("/maintenance/requests/{request_id}")
def update_maintenance_request(request_id: int, update_data: MaintenanceUpdate, 
                             db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") not in [Role.SUPERVISOR, Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    # Default to hostel_id 1 if not set in user profile
    hostel_id = user.get("hostel_id") or 1
    request = db.query(MaintenanceRequest).filter(
        MaintenanceRequest.id == request_id,
        MaintenanceRequest.hostel_id == hostel_id
    ).first()
    
    if not request:
        raise HTTPException(404, "Maintenance request not found")
    
    # Update fields if provided
    if update_data.status:
        request.status = update_data.status
        if update_data.status == "COMPLETED" and update_data.completed_date:
            request.completed_date = update_data.completed_date
    if update_data.priority:
        request.priority = update_data.priority
    if update_data.description:
        request.description = update_data.description
    if update_data.est_cost is not None:
        request.est_cost = update_data.est_cost
    if update_data.actual_cost is not None:
        request.actual_cost = update_data.actual_cost
    if update_data.assigned_to_id:
        request.assigned_to_id = update_data.assigned_to_id
    if update_data.scheduled_date:
        request.scheduled_date = update_data.scheduled_date
    
    db.commit()
    return {"ok": True}

@router.put("/maintenance/requests/{request_id}/status")
def update_maintenance_request_status(request_id: int, status_data: dict, 
                                    db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") not in [Role.SUPERVISOR, Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    # Default to hostel_id 1 if not set in user profile
    hostel_id = user.get("hostel_id") or 1
    request = db.query(MaintenanceRequest).filter(
        MaintenanceRequest.id == request_id,
        MaintenanceRequest.hostel_id == hostel_id
    ).first()
    
    if not request:
        raise HTTPException(404, "Maintenance request not found")
    
    new_status = status_data.get("status")
    if not new_status:
        raise HTTPException(400, "Status is required")
    
    request.status = new_status
    if new_status == "COMPLETED" and status_data.get("completed_date"):
        request.completed_date = datetime.fromisoformat(status_data["completed_date"]) if isinstance(status_data["completed_date"], str) else status_data["completed_date"]
    
    db.commit()
    return {"ok": True, "message": f"Status updated to {new_status}"}

@router.get("/maintenance/requests/high-value")
def get_high_value_requests(threshold: float = 1000, db: Session = Depends(get_db), user=Depends(current_user)):
    """Get maintenance requests exceeding cost threshold requiring approval"""
    if user.get("role") not in [Role.SUPERVISOR, Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    # Default to hostel_id 1 if not set in user profile
    hostel_id = user.get("hostel_id") or 1
    requests = db.query(MaintenanceRequest).filter(
        MaintenanceRequest.hostel_id == hostel_id,
        MaintenanceRequest.est_cost >= threshold,
        MaintenanceRequest.approved == False
    ).all()
    
    return {"high_value_requests": [{"id": r.id, "category": r.category, "priority": r.priority,
                                   "description": r.description, "est_cost": r.est_cost,
                                   "created_at": r.created_at} for r in requests]}

# Maintenance Task Assignment
@router.post("/maintenance/tasks")
def create_maintenance_task(task_data: MaintenanceTaskCreate, db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") not in [Role.SUPERVISOR, Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    # Verify the maintenance request exists and belongs to this hostel
    # Default to hostel_id 1 if not set in user profile
    hostel_id = user.get("hostel_id") or 1
    maintenance_request = db.query(MaintenanceRequest).filter(
        MaintenanceRequest.id == task_data.maintenance_request_id,
        MaintenanceRequest.hostel_id == hostel_id
    ).first()
    
    if not maintenance_request:
        raise HTTPException(404, "Maintenance request not found")
    
    from app.models.maintenance import MaintenanceTask
    task = MaintenanceTask(
        maintenance_request_id=task_data.maintenance_request_id,
        assigned_to_id=task_data.assigned_to_id,
        task_title=task_data.task_title,
        task_description=task_data.task_description,
        priority=task_data.priority,
        estimated_hours=task_data.estimated_hours,
        scheduled_date=task_data.scheduled_date
    )
    db.add(task)
    db.commit()
    db.refresh(task)
    return {"id": task.id, "message": "Task assigned successfully"}

@router.get("/maintenance/tasks")
def get_maintenance_tasks(status: Optional[str] = None, assigned_to_id: Optional[int] = None,
                        skip: int = 0, limit: int = 100, db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") not in [Role.SUPERVISOR, Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    from app.models.maintenance import MaintenanceTask
    # Default to hostel_id 1 if not set in user profile
    hostel_id = user.get("hostel_id") or 1
    query = db.query(MaintenanceTask).join(MaintenanceRequest).filter(
        MaintenanceRequest.hostel_id == hostel_id
    )
    
    if status:
        query = query.filter(MaintenanceTask.status == status)
    if assigned_to_id:
        query = query.filter(MaintenanceTask.assigned_to_id == assigned_to_id)
    
    tasks = query.offset(skip).limit(limit).all()
    return {"tasks": [{"id": t.id, "maintenance_request_id": t.maintenance_request_id,
                      "assigned_to_id": t.assigned_to_id, "task_title": t.task_title,
                      "task_description": t.task_description, "status": t.status,
                      "priority": t.priority, "estimated_hours": t.estimated_hours,
                      "actual_hours": t.actual_hours, "quality_rating": t.quality_rating,
                      "scheduled_date": t.scheduled_date, "completed_date": t.completed_date} for t in tasks]}

@router.put("/maintenance/tasks/{task_id}")
def update_maintenance_task(task_id: int, update_data: MaintenanceTaskUpdate,
                          db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") not in [Role.SUPERVISOR, Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    from app.models.maintenance import MaintenanceTask
    task = db.query(MaintenanceTask).join(MaintenanceRequest).filter(
        MaintenanceTask.id == task_id,
        MaintenanceRequest.hostel_id == user.get("hostel_id")
    ).first()
    
    if not task:
        raise HTTPException(404, "Task not found")
    
    # Update task fields
    if update_data.status:
        task.status = update_data.status
        if update_data.status == "IN_PROGRESS" and update_data.started_date:
            task.started_date = update_data.started_date
        elif update_data.status == "COMPLETED" and update_data.completed_date:
            task.completed_date = update_data.completed_date
    
    if update_data.actual_hours is not None:
        task.actual_hours = update_data.actual_hours
    if update_data.quality_rating is not None:
        task.quality_rating = update_data.quality_rating
    if update_data.completion_notes:
        task.completion_notes = update_data.completion_notes
    if update_data.verification_notes:
        task.verification_notes = update_data.verification_notes
        task.verified_by_id = user.get("id")
        task.verified_date = datetime.now()
    
    db.commit()
    return {"ok": True}

# Complaint Management
@router.get("/complaints")
def get_complaints(status: Optional[str] = None, priority: Optional[str] = None, 
                  db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") not in [Role.SUPERVISOR, Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    query = db.query(Complaint).filter(Complaint.hostel_id == user.get("hostel_id"))
    if status:
        query = query.filter(Complaint.status == status)
    if priority:
        query = query.filter(Complaint.priority == priority)
    
    complaints = query.all()
    return {"complaints": [{"id": c.id, "student_id": c.student_id, "category": c.category, 
                           "priority": c.priority, "status": c.status, "description": c.description} for c in complaints]}

@router.put("/complaints/{complaint_id}/assign")
def assign_complaint(complaint_id: int, assigned_to: str, db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") not in [Role.SUPERVISOR, Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    complaint = db.query(Complaint).filter(
        Complaint.id == complaint_id,
        Complaint.hostel_id == user.get("hostel_id")
    ).first()
    
    if not complaint:
        raise HTTPException(404, "Complaint not found")
    
    complaint.status = "ASSIGNED"
    # Note: You might want to add an assigned_to field to the Complaint model
    db.commit()
    return {"ok": True}

# Leave Request Management
@router.get("/leave/requests")
def get_leave_requests(status: Optional[str] = None, db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") not in [Role.SUPERVISOR, Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    # Default to hostel_id 1 if not set in user profile
    hostel_id = user.get("hostel_id") or 1
    query = db.query(LeaveRequest).filter(LeaveRequest.hostel_id == hostel_id)
    if status:
        query = query.filter(LeaveRequest.status == status)
    
    requests = query.all()
    return {"requests": [{"id": r.id, "student_id": r.student_id, "start_date": r.start_date, 
                         "end_date": r.end_date, "reason": r.reason, "status": r.status} for r in requests]}

@router.put("/leave/requests/{request_id}/review")
def review_leave_request(request_id: int, status: str, db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") not in [Role.SUPERVISOR, Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    if status not in ["APPROVED", "REJECTED"]:
        raise HTTPException(400, "Status must be APPROVED or REJECTED")
    
    # Default to hostel_id 1 if not set in user profile
    hostel_id = user.get("hostel_id") or 1
    request = db.query(LeaveRequest).filter(
        LeaveRequest.id == request_id,
        LeaveRequest.hostel_id == hostel_id
    ).first()
    
    if not request:
        raise HTTPException(404, "Leave request not found")
    
    request.status = status
    db.commit()
    return {"ok": True}

# Maintenance Cost Tracking
@router.post("/maintenance/costs")
def add_maintenance_cost(cost_data: MaintenanceCostCreate, db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") not in [Role.SUPERVISOR, Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    # Verify the maintenance request exists and belongs to this hostel
    # Default to hostel_id 1 if not set in user profile
    hostel_id = user.get("hostel_id") or 1
    maintenance_request = db.query(MaintenanceRequest).filter(
        MaintenanceRequest.id == cost_data.maintenance_request_id,
        MaintenanceRequest.hostel_id == hostel_id
    ).first()
    
    if not maintenance_request:
        raise HTTPException(404, "Maintenance request not found")
    
    cost = MaintenanceCost(
        maintenance_request_id=cost_data.maintenance_request_id,
        hostel_id=hostel_id,
        category=cost_data.category,
        vendor_name=cost_data.vendor_name,
        description=cost_data.description,
        amount=cost_data.amount,
        invoice_url=cost_data.invoice_url,
        payment_method=cost_data.payment_method
    )
    db.add(cost)
    db.commit()
    db.refresh(cost)
    return {"id": cost.id, "message": "Cost recorded successfully"}

@router.get("/maintenance/costs")
def get_maintenance_costs(maintenance_request_id: Optional[int] = None, category: Optional[str] = None,
                        payment_status: Optional[str] = None, skip: int = 0, limit: int = 100,
                        db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") not in [Role.SUPERVISOR, Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    # Default to hostel_id 1 if not set in user profile
    hostel_id = user.get("hostel_id") or 1
    query = db.query(MaintenanceCost).filter(MaintenanceCost.hostel_id == hostel_id)
    
    if maintenance_request_id:
        query = query.filter(MaintenanceCost.maintenance_request_id == maintenance_request_id)
    if category:
        query = query.filter(MaintenanceCost.category == category)
    if payment_status:
        query = query.filter(MaintenanceCost.payment_status == payment_status)
    
    costs = query.offset(skip).limit(limit).all()
    return {"costs": [{"id": c.id, "maintenance_request_id": c.maintenance_request_id,
                      "category": c.category, "vendor_name": c.vendor_name,
                      "description": c.description, "amount": c.amount,
                      "payment_status": c.payment_status, "payment_method": c.payment_method,
                      "invoice_url": c.invoice_url, "created_at": c.created_at} for c in costs]}

@router.put("/maintenance/costs/{cost_id}/payment")
def update_cost_payment_status(cost_id: int, payment_status: str, payment_method: Optional[str] = None,
                             db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") not in [Role.SUPERVISOR, Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    # Default to hostel_id 1 if not set in user profile
    hostel_id = user.get("hostel_id") or 1
    cost = db.query(MaintenanceCost).filter(
        MaintenanceCost.id == cost_id,
        MaintenanceCost.hostel_id == hostel_id
    ).first()
    
    if not cost:
        raise HTTPException(404, "Cost record not found")
    
    cost.payment_status = payment_status
    if payment_method:
        cost.payment_method = payment_method
    if payment_status == "PAID":
        cost.paid_date = datetime.now()
    
    db.commit()
    return {"ok": True}

# Budget Tracking and Analytics
@router.get("/maintenance/budget/summary")
def get_budget_summary(category: Optional[str] = None, start_date: Optional[str] = None, 
                      end_date: Optional[str] = None, db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") not in [Role.SUPERVISOR, Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    # Default to hostel_id 1 if not set in user profile
    hostel_id = user.get("hostel_id") or 1
    query = db.query(MaintenanceCost).filter(MaintenanceCost.hostel_id == hostel_id)
    
    if category:
        query = query.filter(MaintenanceCost.category == category)
    if start_date:
        start = datetime.strptime(start_date, "%Y-%m-%d")
        query = query.filter(MaintenanceCost.created_at >= start)
    if end_date:
        end = datetime.strptime(end_date, "%Y-%m-%d")
        query = query.filter(MaintenanceCost.created_at <= end)
    
    total_spent = query.with_entities(func.sum(MaintenanceCost.amount)).scalar() or 0
    pending_payments = query.filter(MaintenanceCost.payment_status == "PENDING").with_entities(func.sum(MaintenanceCost.amount)).scalar() or 0
    paid_amount = query.filter(MaintenanceCost.payment_status == "PAID").with_entities(func.sum(MaintenanceCost.amount)).scalar() or 0
    
    # Category breakdown
    category_breakdown = {}
    categories = query.with_entities(MaintenanceCost.category).distinct().all()
    for (cat,) in categories:
        cat_total = query.filter(MaintenanceCost.category == cat).with_entities(func.sum(MaintenanceCost.amount)).scalar() or 0
        category_breakdown[cat] = cat_total
    
    return {
        "total_spent": total_spent,
        "pending_payments": pending_payments,
        "paid_amount": paid_amount,
        "category_breakdown": category_breakdown
    }

@router.get("/maintenance/analytics")
def get_maintenance_analytics(days: int = 30, db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") not in [Role.SUPERVISOR, Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    from datetime import timedelta
    start_date = datetime.now() - timedelta(days=days)
    
    # Request analytics
    total_requests = db.query(MaintenanceRequest).filter(
        MaintenanceRequest.hostel_id == user.get("hostel_id"),
        MaintenanceRequest.created_at >= start_date
    ).count()
    
    completed_requests = db.query(MaintenanceRequest).filter(
        MaintenanceRequest.hostel_id == user.get("hostel_id"),
        MaintenanceRequest.status == "COMPLETED",
        MaintenanceRequest.created_at >= start_date
    ).count()
    
    pending_requests = db.query(MaintenanceRequest).filter(
        MaintenanceRequest.hostel_id == user.get("hostel_id"),
        MaintenanceRequest.status == "PENDING",
        MaintenanceRequest.created_at >= start_date
    ).count()
    
    # Cost analytics
    total_cost = db.query(MaintenanceCost).filter(
        MaintenanceCost.hostel_id == user.get("hostel_id"),
        MaintenanceCost.created_at >= start_date
    ).with_entities(func.sum(MaintenanceCost.amount)).scalar() or 0
    
    # Average completion time
    completed_with_dates = db.query(MaintenanceRequest).filter(
        MaintenanceRequest.hostel_id == user.get("hostel_id"),
        MaintenanceRequest.status == "COMPLETED",
        MaintenanceRequest.completed_date.isnot(None),
        MaintenanceRequest.created_at >= start_date
    ).all()
    
    avg_completion_hours = 0
    if completed_with_dates:
        total_hours = sum([(r.completed_date - r.created_at).total_seconds() / 3600 for r in completed_with_dates])
        avg_completion_hours = total_hours / len(completed_with_dates)
    
    return {
        "period_days": days,
        "total_requests": total_requests,
        "completed_requests": completed_requests,
        "pending_requests": pending_requests,
        "completion_rate": round((completed_requests / total_requests * 100) if total_requests > 0 else 0, 2),
        "total_cost": total_cost,
        "avg_completion_time_hours": round(avg_completion_hours, 2)
    }