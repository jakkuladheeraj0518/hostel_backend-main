from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import Optional
from app.core.database import get_db
from app.api.deps import current_user
from app.core.rbac import Role
from app.schemas.review_schema import ReviewCreate
from app.schemas.leave_schema import LeaveCreate
from app.schemas.complaint_schema import ComplaintCreate
from app.models.review import Review
from app.models.leave import LeaveRequest
from app.models.maintenance import Complaint
from app.models.notice import Notice
from app.models.attendance import Attendance

router = APIRouter(prefix="/student", tags=["Student"])

# Student Profile
@router.get("/profile")
def get_student_profile(db: Session = Depends(get_db), user=Depends(current_user)):
    """Get student profile information"""
    if user.get("role") != Role.STUDENT:
        raise HTTPException(403, "Only students can access this")
    
    from app.models.user import User
    student = db.query(User).filter(User.id == user.get("id")).first()
    if not student:
        raise HTTPException(404, "Student not found")
    
    return {
        "id": student.id,
        "email": student.email,
        "full_name": student.full_name,
        "role": student.role,
        "hostel_id": student.hostel_id,
        "phone": student.phone,
        "room_number": student.room_number,
        "bed_number": student.bed_number,
        "check_in_date": student.check_in_date
    }

# Review System
@router.post("/reviews/{hostel_id}")
def post_review(hostel_id: int, body: ReviewCreate, db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") != Role.STUDENT:
        raise HTTPException(403, "Only students can post reviews")
    
    # Check if student already reviewed this hostel
    existing = db.query(Review).filter(Review.hostel_id == hostel_id, Review.student_id == user.get("id")).first()
    if existing:
        raise HTTPException(400, "You have already reviewed this hostel")
    
    # Content filtering and spam detection
    from app.utils.content_filter import detect_spam, detect_inappropriate_content, content_quality_score
    
    is_spam, spam_keywords = detect_spam(body.text)
    is_inappropriate, inappropriate_keywords = detect_inappropriate_content(body.text)
    quality_score = content_quality_score(body.text, body.rating)
    
    if is_inappropriate:
        raise HTTPException(400, f"Review contains inappropriate content: {', '.join(inappropriate_keywords)}")
    
    # Auto-approve high quality reviews, flag low quality ones for manual review
    auto_approve = quality_score > 0.7 and not is_spam
    
    r = Review(
        hostel_id=hostel_id, 
        student_id=user.get("id"), 
        rating=body.rating, 
        text=body.text, 
        photo_url=body.photo_url,
        is_approved=auto_approve
    )
    db.add(r)
    db.commit()
    db.refresh(r)
    
    message = "Review submitted and approved" if auto_approve else "Review submitted for moderation"
    if is_spam:
        message += " (flagged for spam review)"
    
    return {"id": r.id, "message": message, "auto_approved": auto_approve}

@router.get("/reviews/my")
def get_my_reviews(db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") != Role.STUDENT:
        raise HTTPException(403, "Only students can access this")
    
    reviews = db.query(Review).filter(Review.student_id == user.get("id")).all()
    return {"reviews": [{"id": r.id, "hostel_id": r.hostel_id, "rating": r.rating, "text": r.text, 
                        "is_approved": r.is_approved, "helpful_count": r.helpful_count} for r in reviews]}

@router.put("/reviews/{review_id}")
def update_review(review_id: int, body: ReviewCreate, db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") != Role.STUDENT:
        raise HTTPException(403, "Only students can update reviews")
    
    review = db.query(Review).filter(Review.id == review_id, Review.student_id == user.get("id")).first()
    if not review:
        raise HTTPException(404, "Review not found or not owned by you")
    
    review.rating = body.rating
    review.text = body.text
    review.photo_url = body.photo_url
    review.is_approved = False  # Reset approval status
    db.commit()
    return {"ok": True}

@router.post("/reviews/{review_id}/helpful")
def mark_review_helpful(review_id: int, db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") != Role.STUDENT:
        raise HTTPException(403, "Only students can mark reviews as helpful")
    
    review = db.query(Review).filter(Review.id == review_id).first()
    if not review:
        raise HTTPException(404, "Review not found")
    
    if not review.is_approved or review.is_spam:
        raise HTTPException(400, "Cannot mark this review as helpful")
    
    # Check if user already marked this review as helpful
    from app.models.review import ReviewHelpful
    existing = db.query(ReviewHelpful).filter(
        ReviewHelpful.review_id == review_id,
        ReviewHelpful.user_id == user.get("id")
    ).first()
    
    if existing:
        raise HTTPException(400, "You have already marked this review as helpful")
    
    # Add helpful vote
    helpful_vote = ReviewHelpful(review_id=review_id, user_id=user.get("id"))
    db.add(helpful_vote)
    
    # Update helpful count
    review.helpful_count += 1
    db.commit()
    return {"ok": True, "helpful_count": review.helpful_count}

@router.delete("/reviews/{review_id}")
def delete_my_review(review_id: int, db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") != Role.STUDENT:
        raise HTTPException(403, "Only students can delete their reviews")
    
    review = db.query(Review).filter(Review.id == review_id, Review.student_id == user.get("id")).first()
    if not review:
        raise HTTPException(404, "Review not found or not owned by you")
    
    db.delete(review)
    db.commit()
    return {"ok": True}

@router.get("/reviews/can-review/{hostel_id}")
def can_review_hostel(hostel_id: int, db: Session = Depends(get_db), user=Depends(current_user)):
    """Check if student can review a specific hostel"""
    if user.get("role") != Role.STUDENT:
        raise HTTPException(403, "Only students can check review eligibility")
    
    existing = db.query(Review).filter(
        Review.hostel_id == hostel_id, 
        Review.student_id == user.get("id")
    ).first()
    
    return {"can_review": existing is None, "has_existing_review": existing is not None}

# Leave Application Management
@router.post("/leave/apply")
def apply_leave(leave_data: LeaveCreate, hostel_id: int, db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") != Role.STUDENT:
        raise HTTPException(403, "Only students can apply for leave")
    
    leave_request = LeaveRequest(
        hostel_id=hostel_id,
        student_id=user.get("id"),
        start_date=leave_data.start,
        end_date=leave_data.end,
        reason=leave_data.reason
    )
    db.add(leave_request)
    db.commit()
    db.refresh(leave_request)
    return {"id": leave_request.id}

@router.get("/leave/my")
def get_my_leave_requests(db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") != Role.STUDENT:
        raise HTTPException(403, "Only students can access this")
    
    requests = db.query(LeaveRequest).filter(LeaveRequest.student_id == user.get("id")).all()
    return {"requests": [{"id": r.id, "hostel_id": r.hostel_id, "start_date": r.start_date, 
                         "end_date": r.end_date, "reason": r.reason, "status": r.status} for r in requests]}

@router.put("/leave/{request_id}/cancel")
def cancel_leave_request(request_id: int, db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") != Role.STUDENT:
        raise HTTPException(403, "Only students can cancel their leave")
    
    request = db.query(LeaveRequest).filter(LeaveRequest.id == request_id, LeaveRequest.student_id == user.get("id")).first()
    if not request:
        raise HTTPException(404, "Leave request not found or not owned by you")
    
    if request.status != "PENDING":
        raise HTTPException(400, "Can only cancel pending requests")
    
    request.status = "CANCELLED"
    db.commit()
    return {"ok": True}

@router.get("/leave/balance")
def get_leave_balance(db: Session = Depends(get_db), user=Depends(current_user)):
    """Get student's leave balance and usage statistics"""
    if user.get("role") != Role.STUDENT:
        raise HTTPException(403, "Only students can access this")
    
    from datetime import datetime, timedelta
    from sqlalchemy import and_, extract
    
    # Calculate leave usage for current year
    current_year = datetime.now().year
    
    # Get all approved leave requests for current year
    approved_leaves = db.query(LeaveRequest).filter(
        and_(
            LeaveRequest.student_id == user.get("id"),
            LeaveRequest.status == "APPROVED",
            extract('year', LeaveRequest.start_date) == current_year
        )
    ).all()
    
    # Calculate total used days
    used_days = 0
    for leave in approved_leaves:
        if leave.start_date and leave.end_date:
            delta = leave.end_date - leave.start_date
            used_days += delta.days + 1  # +1 to include both start and end dates
    
    # Standard leave allocation (can be configured per hostel)
    total_annual_leave = 30  # 30 days per year standard
    remaining_days = max(0, total_annual_leave - used_days)
    
    # Get pending requests
    pending_requests = db.query(LeaveRequest).filter(
        and_(
            LeaveRequest.student_id == user.get("id"),
            LeaveRequest.status == "PENDING",
            extract('year', LeaveRequest.start_date) == current_year
        )
    ).count()
    
    return {
        "total_days": total_annual_leave,
        "used_days": used_days,
        "remaining_days": remaining_days,
        "pending_requests": pending_requests,
        "year": current_year
    }

# Complaint System
@router.post("/complaints")
def submit_complaint(complaint_data: ComplaintCreate, hostel_id: int, 
                    db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") != Role.STUDENT:
        raise HTTPException(403, "Only students can submit complaints")
    
    complaint = Complaint(
        hostel_id=hostel_id,
        student_id=user.get("id"),
        category=complaint_data.category,
        priority=complaint_data.priority,
        description=complaint_data.description
    )
    db.add(complaint)
    db.commit()
    db.refresh(complaint)
    return {"id": complaint.id}

@router.get("/complaints/my")
def get_my_complaints(db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") != Role.STUDENT:
        raise HTTPException(403, "Only students can access this")
    
    complaints = db.query(Complaint).filter(Complaint.student_id == user.get("id")).all()
    return {"complaints": [{"id": c.id, "hostel_id": c.hostel_id, "category": c.category, 
                           "priority": c.priority, "status": c.status, "description": c.description} for c in complaints]}

# Notice Viewing
@router.get("/notices")
def get_notices(hostel_id: Optional[int] = None, db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") != Role.STUDENT:
        raise HTTPException(403, "Only students can access this")
    
    query = db.query(Notice).filter(Notice.audience.in_(["ALL", "STUDENTS"]))
    if hostel_id:
        query = query.filter(Notice.hostel_id == hostel_id)
    
    notices = query.all()
    return {"notices": [{"id": n.id, "hostel_id": n.hostel_id, "title": n.title, 
                        "content": n.content, "audience": n.audience} for n in notices]}

# Attendance Viewing
@router.get("/attendance/my")
def get_my_attendance(hostel_id: int, start_date: Optional[str] = None, end_date: Optional[str] = None, 
                     db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") != Role.STUDENT:
        raise HTTPException(403, "Only students can access this")
    
    query = db.query(Attendance).filter(Attendance.student_id == user.get("id"), Attendance.hostel_id == hostel_id)
    
    if start_date:
        from datetime import datetime
        start = datetime.strptime(start_date, "%Y-%m-%d").date()
        query = query.filter(Attendance.date >= start)
    
    if end_date:
        from datetime import datetime
        end = datetime.strptime(end_date, "%Y-%m-%d").date()
        query = query.filter(Attendance.date <= end)
    
    attendance = query.all()
    return {"attendance": [{"id": a.id, "date": a.date, "status": a.status} for a in attendance]}
