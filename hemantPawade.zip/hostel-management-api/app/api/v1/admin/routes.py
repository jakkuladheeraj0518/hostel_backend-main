from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import func, desc
from typing import List, Optional
from datetime import datetime
from app.core.database import get_db
from app.api.deps import current_user
from app.core.rbac import Role
from app.models.hostel import AdminHostel, Hostel
from app.models.user import User
from app.models.review import Review
from app.models.maintenance import Complaint, MaintenanceRequest, MaintenanceCost, MaintenanceTask
from app.models.leave import LeaveRequest
from app.models.notice import Notice
from app.schemas.user_schema import UserCreate, UserOut
from app.schemas.notice_schema import NoticeCreate
from app.schemas.maintenance_schema import MaintenanceCreate, MaintenanceUpdate, MaintenanceCostCreate
from app.schemas.preventive_maintenance_schema import PreventiveMaintenanceScheduleCreate, PreventiveMaintenanceTaskCreate, PreventiveMaintenanceTaskUpdate
from app.models.preventive_maintenance import PreventiveMaintenanceSchedule, PreventiveMaintenanceTask

router = APIRouter(prefix="/admin", tags=["Admin"])

# Admin Dashboard
@router.get("/dashboard")
def get_admin_dashboard(db: Session = Depends(get_db), user=Depends(current_user)):
    """Get admin dashboard overview"""
    if user.get("role") not in [Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    # Get basic statistics
    total_users = db.query(User).count()
    total_hostels = db.query(Hostel).count()
    total_reviews = db.query(Review).count()
    pending_reviews = db.query(Review).filter(Review.is_approved == False, Review.is_spam == False).count()
    
    return {
        "total_users": total_users,
        "total_hostels": total_hostels,
        "total_reviews": total_reviews,
        "pending_reviews": pending_reviews
    }

# Hostel Management
@router.post("/assign-hostel")
def assign_hostel(admin_id: int, hostel_id: int, db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") not in [Role.SUPER_ADMIN, Role.ADMIN]:
        raise HTTPException(403, "Forbidden")
    link = AdminHostel(admin_id=admin_id, hostel_id=hostel_id)
    db.add(link); db.commit(); db.refresh(link)
    return {"ok": True, "id": link.id}

@router.get("/hostels")
def get_managed_hostels(db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") not in [Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    if user.get("role") == Role.SUPER_ADMIN:
        hostels = db.query(Hostel).all()
    else:
        hostel_links = db.query(AdminHostel).filter(AdminHostel.admin_id == user.get("id")).all()
        hostel_ids = [link.hostel_id for link in hostel_links]
        hostels = db.query(Hostel).filter(Hostel.id.in_(hostel_ids)).all()
    
    return {"hostels": [{"id": h.id, "name": h.name} for h in hostels]}

# User Management
@router.post("/users", response_model=UserOut)
def create_user(user_data: UserCreate, db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") not in [Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    if db.query(User).filter(User.email == user_data.email).first():
        raise HTTPException(400, "Email already registered")
    
    from app.core.security import hash_password
    new_user = User(
        email=user_data.email,
        full_name=user_data.full_name,
        hashed_password=hash_password(user_data.password),
        role=user_data.role
    )
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    return new_user

@router.get("/users")
def get_users(skip: int = 0, limit: int = 100, db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") not in [Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    users = db.query(User).offset(skip).limit(limit).all()
    return {"users": [{"id": u.id, "email": u.email, "full_name": u.full_name, "role": u.role, "is_active": u.is_active} for u in users]}

@router.put("/users/{user_id}/status")
def update_user_status(user_id: int, is_active: bool, db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") not in [Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    target_user = db.query(User).filter(User.id == user_id).first()
    if not target_user:
        raise HTTPException(404, "User not found")
    
    target_user.is_active = is_active
    db.commit()
    return {"ok": True}

# Review Management
@router.get("/reviews")
def get_reviews(hostel_id: Optional[int] = None, status: Optional[str] = None, 
                rating: Optional[int] = None, is_spam: Optional[bool] = None,
                skip: int = 0, limit: int = 100, sort_by: str = "newest",
                db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") not in [Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    query = db.query(Review)
    
    # Apply filters
    if hostel_id:
        query = query.filter(Review.hostel_id == hostel_id)
    if status == "approved":
        query = query.filter(Review.is_approved == True)
    elif status == "pending":
        query = query.filter(Review.is_approved == False)
    if rating:
        query = query.filter(Review.rating == rating)
    if is_spam is not None:
        query = query.filter(Review.is_spam == is_spam)
    
    # Apply sorting
    if sort_by == "newest":
        query = query.order_by(desc(Review.created_at))
    elif sort_by == "oldest":
        query = query.order_by(Review.created_at)
    elif sort_by == "highest_rating":
        query = query.order_by(desc(Review.rating))
    elif sort_by == "lowest_rating":
        query = query.order_by(Review.rating)
    elif sort_by == "most_helpful":
        query = query.order_by(desc(Review.helpful_count))
    
    reviews = query.offset(skip).limit(limit).all()
    return {"reviews": [{"id": r.id, "hostel_id": r.hostel_id, "student_id": r.student_id,
                        "rating": r.rating, "text": r.text, "photo_url": r.photo_url,
                        "is_approved": r.is_approved, "is_spam": r.is_spam,
                        "helpful_count": r.helpful_count, "created_at": r.created_at} for r in reviews]}

@router.get("/reviews/pending")
def get_pending_reviews(skip: int = 0, limit: int = 50, db: Session = Depends(get_db), user=Depends(current_user)):
    """Get reviews pending moderation"""
    if user.get("role") not in [Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    reviews = db.query(Review).filter(
        Review.is_approved == False,
        Review.is_spam == False
    ).order_by(desc(Review.created_at)).offset(skip).limit(limit).all()
    
    return {"reviews": [{"id": r.id, "hostel_id": r.hostel_id, "student_id": r.student_id,
                        "rating": r.rating, "text": r.text, "photo_url": r.photo_url,
                        "created_at": r.created_at} for r in reviews]}

@router.put("/reviews/{review_id}/moderate")
def moderate_review(review_id: int, action: str, reason: Optional[str] = None, 
                   db: Session = Depends(get_db), user=Depends(current_user)):
    """Comprehensive review moderation with spam detection"""
    if user.get("role") not in [Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    review = db.query(Review).filter(Review.id == review_id).first()
    if not review:
        raise HTTPException(404, "Review not found")
    
    if action == "approve":
        review.is_approved = True
        review.is_spam = False
    elif action == "reject":
        review.is_approved = False
    elif action == "mark_spam":
        review.is_spam = True
        review.is_approved = False
    elif action == "unmark_spam":
        review.is_spam = False
    else:
        raise HTTPException(400, "Invalid action. Use: approve, reject, mark_spam, unmark_spam")
    
    db.commit()
    return {"ok": True, "action": action}

@router.get("/reviews/spam")
def get_spam_reviews(skip: int = 0, limit: int = 50, db: Session = Depends(get_db), user=Depends(current_user)):
    """Get reviews marked as spam"""
    if user.get("role") not in [Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    reviews = db.query(Review).filter(Review.is_spam == True).offset(skip).limit(limit).all()
    return {"reviews": [{"id": r.id, "hostel_id": r.hostel_id, "rating": r.rating, 
                        "text": r.text, "created_at": r.created_at} for r in reviews]}

@router.get("/reviews/analytics")
def get_review_analytics(hostel_id: Optional[int] = None, days: int = 30, 
                        db: Session = Depends(get_db), user=Depends(current_user)):
    """Get review analytics and insights"""
    if user.get("role") not in [Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    from datetime import datetime, timedelta
    start_date = datetime.now() - timedelta(days=days)
    
    query = db.query(Review).filter(Review.created_at >= start_date)
    if hostel_id:
        query = query.filter(Review.hostel_id == hostel_id)
    
    total_reviews = query.count()
    approved_reviews = query.filter(Review.is_approved == True).count()
    spam_reviews = query.filter(Review.is_spam == True).count()
    pending_reviews = query.filter(Review.is_approved == False, Review.is_spam == False).count()
    
    avg_rating = query.filter(Review.is_approved == True).with_entities(func.avg(Review.rating)).scalar() or 0
    
    # Rating distribution
    rating_dist = {}
    for i in range(1, 6):
        count = query.filter(Review.rating == i, Review.is_approved == True).count()
        rating_dist[f"{i}_star"] = count
    
    return {
        "period_days": days,
        "total_reviews": total_reviews,
        "approved_reviews": approved_reviews,
        "pending_reviews": pending_reviews,
        "spam_reviews": spam_reviews,
        "avg_rating": round(avg_rating, 2),
        "rating_distribution": rating_dist,
        "approval_rate": round((approved_reviews / total_reviews * 100) if total_reviews > 0 else 0, 2)
    }

@router.delete("/reviews/{review_id}")
def delete_review(review_id: int, db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") not in [Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    review = db.query(Review).filter(Review.id == review_id).first()
    if not review:
        raise HTTPException(404, "Review not found")
    
    db.delete(review)
    db.commit()
    return {"ok": True}

# Maintenance Management
@router.get("/maintenance/requests")
def get_maintenance_requests(hostel_id: Optional[int] = None, status: Optional[str] = None, 
                           category: Optional[str] = None, priority: Optional[str] = None,
                           approved: Optional[bool] = None, skip: int = 0, limit: int = 100,
                           sort_by: str = "created_at", db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") not in [Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    query = db.query(MaintenanceRequest)
    
    # Apply filters
    if hostel_id:
        query = query.filter(MaintenanceRequest.hostel_id == hostel_id)
    if status:
        query = query.filter(MaintenanceRequest.status == status)
    if category:
        query = query.filter(MaintenanceRequest.category == category)
    if priority:
        query = query.filter(MaintenanceRequest.priority == priority)
    if approved is not None:
        query = query.filter(MaintenanceRequest.approved == approved)
    
    # Apply sorting
    if sort_by == "created_at":
        query = query.order_by(desc(MaintenanceRequest.created_at))
    elif sort_by == "priority":
        # Custom priority ordering: URGENT > HIGH > MEDIUM > LOW
        priority_order = {"URGENT": 4, "HIGH": 3, "MEDIUM": 2, "LOW": 1}
        query = query.order_by(desc(MaintenanceRequest.priority))
    elif sort_by == "cost":
        query = query.order_by(desc(MaintenanceRequest.est_cost))
    
    requests = query.offset(skip).limit(limit).all()
    return {"requests": [{"id": r.id, "hostel_id": r.hostel_id, "created_by_id": r.created_by_id,
                         "category": r.category, "priority": r.priority, "status": r.status,
                         "description": r.description, "photo_url": r.photo_url,
                         "est_cost": r.est_cost, "actual_cost": r.actual_cost, "approved": r.approved,
                         "assigned_to_id": r.assigned_to_id, "scheduled_date": r.scheduled_date,
                         "completed_date": r.completed_date, "created_at": r.created_at} for r in requests]}

@router.get("/maintenance/requests/high-value")
def get_high_value_requests(threshold: float = 1000, skip: int = 0, limit: int = 50,
                          db: Session = Depends(get_db), user=Depends(current_user)):
    """Get high-value maintenance requests requiring admin approval"""
    if user.get("role") not in [Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    requests = db.query(MaintenanceRequest).filter(
        MaintenanceRequest.est_cost >= threshold,
        MaintenanceRequest.approved == False
    ).order_by(desc(MaintenanceRequest.est_cost)).offset(skip).limit(limit).all()
    
    return {"high_value_requests": [{"id": r.id, "hostel_id": r.hostel_id, "category": r.category,
                                   "priority": r.priority, "description": r.description,
                                   "est_cost": r.est_cost, "created_at": r.created_at} for r in requests]}

@router.put("/maintenance/requests/{request_id}/approve")
def approve_maintenance_request(request_id: int, approved: bool, reason: Optional[str] = None,
                              db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") not in [Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    request = db.query(MaintenanceRequest).filter(MaintenanceRequest.id == request_id).first()
    if not request:
        raise HTTPException(404, "Maintenance request not found")
    
    request.approved = approved
    if approved:
        request.status = "APPROVED"
    else:
        request.status = "REJECTED"
    
    db.commit()
    return {"ok": True, "status": "approved" if approved else "rejected"}

@router.put("/maintenance/requests/{request_id}/assign")
def assign_maintenance_request(request_id: int, assignment_data: dict, 
                             db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") not in [Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    request = db.query(MaintenanceRequest).filter(MaintenanceRequest.id == request_id).first()
    if not request:
        raise HTTPException(404, "Maintenance request not found")
    
    # Extract data from request body
    assigned_to_id = assignment_data.get("assigned_to_id")
    scheduled_date = assignment_data.get("scheduled_date")
    
    if not assigned_to_id:
        raise HTTPException(400, "assigned_to_id is required")
    
    # Verify the assigned user exists and has appropriate role
    assigned_user = db.query(User).filter(User.id == assigned_to_id).first()
    if not assigned_user:
        raise HTTPException(404, "Assigned user not found")
    
    request.assigned_to_id = assigned_to_id
    request.status = "ASSIGNED"
    if scheduled_date:
        request.scheduled_date = datetime.fromisoformat(scheduled_date) if isinstance(scheduled_date, str) else scheduled_date
    
    db.commit()
    return {"ok": True, "message": f"Request assigned to {assigned_user.full_name}"}

@router.get("/maintenance/complaints")
def get_complaints(hostel_id: Optional[int] = None, status: Optional[str] = None, 
                  category: Optional[str] = None, priority: Optional[str] = None,
                  skip: int = 0, limit: int = 100, db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") not in [Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    query = db.query(Complaint)
    
    if hostel_id:
        query = query.filter(Complaint.hostel_id == hostel_id)
    if status:
        query = query.filter(Complaint.status == status)
    if category:
        query = query.filter(Complaint.category == category)
    if priority:
        query = query.filter(Complaint.priority == priority)
    
    complaints = query.order_by(desc(Complaint.created_at)).offset(skip).limit(limit).all()
    return {"complaints": [{"id": c.id, "hostel_id": c.hostel_id, "student_id": c.student_id,
                           "category": c.category, "priority": c.priority, "status": c.status,
                           "description": c.description, "photo_url": c.photo_url,
                           "created_at": c.created_at} for c in complaints]}

@router.put("/maintenance/complaints/{complaint_id}/status")
def update_complaint_status(complaint_id: int, status: str, db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") not in [Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    complaint = db.query(Complaint).filter(Complaint.id == complaint_id).first()
    if not complaint:
        raise HTTPException(404, "Complaint not found")
    
    complaint.status = status
    db.commit()
    return {"ok": True}

# Leave Management
@router.get("/leave/requests")
def get_leave_requests(hostel_id: Optional[int] = None, status: Optional[str] = None, 
                      skip: int = 0, limit: int = 100, db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") not in [Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    query = db.query(LeaveRequest)
    if hostel_id:
        query = query.filter(LeaveRequest.hostel_id == hostel_id)
    if status:
        query = query.filter(LeaveRequest.status == status)
    
    requests = query.offset(skip).limit(limit).all()
    return {"requests": [{"id": r.id, "hostel_id": r.hostel_id, "student_id": r.student_id, 
                         "start_date": r.start_date, "end_date": r.end_date, "reason": r.reason, 
                         "status": r.status} for r in requests]}

@router.put("/leave/requests/{request_id}/status")
def update_leave_request_status(request_id: int, status: str, db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") not in [Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    request = db.query(LeaveRequest).filter(LeaveRequest.id == request_id).first()
    if not request:
        raise HTTPException(404, "Leave request not found")
    
    request.status = status
    db.commit()
    return {"ok": True}

# Notice Management
@router.post("/notices")
def create_notice(notice_data: NoticeCreate, hostel_id: int, db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") not in [Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    notice = Notice(
        hostel_id=hostel_id,
        title=notice_data.title,
        content=notice_data.content,
        audience=notice_data.audience
    )
    db.add(notice)
    db.commit()
    db.refresh(notice)
    return {"id": notice.id}

@router.get("/notices")
def get_notices(hostel_id: Optional[int] = None, skip: int = 0, limit: int = 100, 
               db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") not in [Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    query = db.query(Notice)
    if hostel_id:
        query = query.filter(Notice.hostel_id == hostel_id)
    
    notices = query.offset(skip).limit(limit).all()
    return {"notices": [{"id": n.id, "hostel_id": n.hostel_id, "title": n.title, 
                        "content": n.content, "audience": n.audience} for n in notices]}

@router.put("/notices/{notice_id}")
def update_notice(notice_id: int, notice_data: NoticeCreate, db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") not in [Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    notice = db.query(Notice).filter(Notice.id == notice_id).first()
    if not notice:
        raise HTTPException(404, "Notice not found")
    
    notice.title = notice_data.title
    notice.content = notice_data.content
    notice.audience = notice_data.audience
    db.commit()
    return {"ok": True}

@router.delete("/notices/{notice_id}")
def delete_notice(notice_id: int, db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") not in [Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    notice = db.query(Notice).filter(Notice.id == notice_id).first()
    if not notice:
        raise HTTPException(404, "Notice not found")
    
    db.delete(notice)
    db.commit()
    return {"ok": True}

# System Health Check
@router.get("/system/health")
def system_health_check(db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") not in [Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    # Basic system health metrics
    total_users = db.query(User).count()
    total_hostels = db.query(Hostel).count()
    total_reviews = db.query(Review).count()
    pending_reviews = db.query(Review).filter(Review.is_approved == False, Review.is_spam == False).count()
    
    return {
        "status": "healthy",
        "metrics": {
            "total_users": total_users,
            "total_hostels": total_hostels,
            "total_reviews": total_reviews,
            "pending_reviews": pending_reviews
        }
    }

# Additional Analytics
@router.get("/analytics/dashboard")
def get_admin_dashboard(hostel_id: Optional[int] = None, db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") not in [Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    # Get basic counts
    query_base = db.query(Review)
    if hostel_id:
        query_base = query_base.filter(Review.hostel_id == hostel_id)
    
    total_reviews = query_base.count()
    approved_reviews = query_base.filter(Review.is_approved == True).count()
    pending_reviews = query_base.filter(Review.is_approved == False, Review.is_spam == False).count()
    spam_reviews = query_base.filter(Review.is_spam == True).count()
    
    # Get average rating
    avg_rating = query_base.filter(Review.is_approved == True).with_entities(func.avg(Review.rating)).scalar()
    
    return {
        "reviews": {
            "total": total_reviews,
            "approved": approved_reviews,
            "pending": pending_reviews,
            "spam": spam_reviews,
            "avg_rating": round(avg_rating, 2) if avg_rating else 0
        }
    }

# Preventive Maintenance Management
@router.post("/preventive-maintenance/schedules")
def create_preventive_schedule(schedule_data: PreventiveMaintenanceScheduleCreate, 
                              db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") not in [Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    schedule = PreventiveMaintenanceSchedule(
        hostel_id=schedule_data.hostel_id,
        equipment_type=schedule_data.equipment_type,
        maintenance_type=schedule_data.maintenance_type,
        frequency_days=schedule_data.frequency_days,
        next_due=schedule_data.next_due
    )
    db.add(schedule)
    db.commit()
    db.refresh(schedule)
    return {"id": schedule.id}

@router.get("/preventive-maintenance/schedules")
def get_preventive_schedules(hostel_id: Optional[int] = None, db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") not in [Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    query = db.query(PreventiveMaintenanceSchedule).filter(PreventiveMaintenanceSchedule.is_active == True)
    if hostel_id:
        query = query.filter(PreventiveMaintenanceSchedule.hostel_id == hostel_id)
    
    schedules = query.all()
    return {"schedules": [{"id": s.id, "hostel_id": s.hostel_id, "equipment_type": s.equipment_type, 
                          "maintenance_type": s.maintenance_type, "frequency_days": s.frequency_days, 
                          "next_due": s.next_due, "last_maintenance": s.last_maintenance} for s in schedules]}

@router.get("/preventive-maintenance/due")
def get_due_preventive_maintenance(days_ahead: int = 7, hostel_id: Optional[int] = None, 
                                  db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") not in [Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    from datetime import date, timedelta
    due_date = date.today() + timedelta(days=days_ahead)
    
    query = db.query(PreventiveMaintenanceSchedule).filter(
        PreventiveMaintenanceSchedule.is_active == True,
        PreventiveMaintenanceSchedule.next_due <= due_date
    )
    if hostel_id:
        query = query.filter(PreventiveMaintenanceSchedule.hostel_id == hostel_id)
    
    due_schedules = query.all()
    return {"due_schedules": [{"id": s.id, "hostel_id": s.hostel_id, "equipment_type": s.equipment_type, 
                              "maintenance_type": s.maintenance_type, "next_due": s.next_due} for s in due_schedules]}

@router.post("/preventive-maintenance/tasks")
def create_preventive_task(task_data: PreventiveMaintenanceTaskCreate, 
                          db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") not in [Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    task = PreventiveMaintenanceTask(
        schedule_id=task_data.schedule_id,
        assigned_to_id=task_data.assigned_to_id,
        scheduled_date=task_data.scheduled_date
    )
    db.add(task)
    db.commit()
    db.refresh(task)
    return {"id": task.id}

@router.put("/preventive-maintenance/tasks/{task_id}")
def update_preventive_task(task_id: int, task_data: PreventiveMaintenanceTaskUpdate, 
                          db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") not in [Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    task = db.query(PreventiveMaintenanceTask).filter(PreventiveMaintenanceTask.id == task_id).first()
    if not task:
        raise HTTPException(404, "Task not found")
    
    task.status = task_data.status
    if task_data.completed_date:
        task.completed_date = task_data.completed_date
    if task_data.notes:
        task.notes = task_data.notes
    if task_data.cost:
        task.cost = task_data.cost
    
    # If task is completed, update the schedule's next due date
    if task_data.status == "COMPLETED" and task_data.completed_date:
        schedule = db.query(PreventiveMaintenanceSchedule).filter(PreventiveMaintenanceSchedule.id == task.schedule_id).first()
        if schedule:
            from datetime import timedelta
            schedule.last_maintenance = task_data.completed_date
            schedule.next_due = task_data.completed_date + timedelta(days=schedule.frequency_days)
    
    db.commit()
    return {"ok": True}

# Analytics and Reports

@router.get("/analytics/review-summary")
def get_review_analytics(hostel_id: Optional[int] = None, db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") not in [Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    from sqlalchemy import func
    query = db.query(Review)
    if hostel_id:
        query = query.filter(Review.hostel_id == hostel_id)
    
    # Rating distribution
    rating_dist = {}
    for i in range(1, 6):
        count = query.filter(Review.rating == i, Review.is_approved == True).count()
        rating_dist[f"{i}_star"] = count
    
    # Overall stats
    total_reviews = query.filter(Review.is_approved == True).count()
    avg_rating = query.filter(Review.is_approved == True).with_entities(func.avg(Review.rating)).scalar()
    pending_reviews = query.filter(Review.is_approved == False).count()
    
    return {
        "total_reviews": total_reviews,
        "average_rating": round(avg_rating, 2) if avg_rating else 0,
        "pending_reviews": pending_reviews,
        "rating_distribution": rating_dist
    }

# Maintenance Cost Management
@router.get("/maintenance/costs")
def get_all_maintenance_costs(hostel_id: Optional[int] = None, category: Optional[str] = None,
                            payment_status: Optional[str] = None, start_date: Optional[str] = None,
                            end_date: Optional[str] = None, skip: int = 0, limit: int = 100,
                            db: Session = Depends(get_db), user=Depends(current_user)):
    if user.get("role") not in [Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    from app.models.maintenance import MaintenanceCost
    query = db.query(MaintenanceCost)
    
    if hostel_id:
        query = query.filter(MaintenanceCost.hostel_id == hostel_id)
    if category:
        query = query.filter(MaintenanceCost.category == category)
    if payment_status:
        query = query.filter(MaintenanceCost.payment_status == payment_status)
    if start_date:
        start = datetime.strptime(start_date, "%Y-%m-%d")
        query = query.filter(MaintenanceCost.created_at >= start)
    if end_date:
        end = datetime.strptime(end_date, "%Y-%m-%d")
        query = query.filter(MaintenanceCost.created_at <= end)
    
    costs = query.order_by(desc(MaintenanceCost.created_at)).offset(skip).limit(limit).all()
    return {"costs": [{"id": c.id, "maintenance_request_id": c.maintenance_request_id,
                      "hostel_id": c.hostel_id, "category": c.category, "vendor_name": c.vendor_name,
                      "description": c.description, "amount": c.amount, "payment_status": c.payment_status,
                      "payment_method": c.payment_method, "invoice_url": c.invoice_url,
                      "paid_date": c.paid_date, "created_at": c.created_at} for c in costs]}

@router.get("/maintenance/budget/allocation")
def get_budget_allocation(hostel_id: Optional[int] = None, year: Optional[int] = None,
                        db: Session = Depends(get_db), user=Depends(current_user)):
    """Get budget allocation and utilization by hostel and category"""
    if user.get("role") not in [Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    from app.models.maintenance import MaintenanceCost
    from datetime import datetime
    
    current_year = year or datetime.now().year
    start_date = datetime(current_year, 1, 1)
    end_date = datetime(current_year, 12, 31)
    
    query = db.query(MaintenanceCost).filter(
        MaintenanceCost.created_at >= start_date,
        MaintenanceCost.created_at <= end_date
    )
    
    if hostel_id:
        query = query.filter(MaintenanceCost.hostel_id == hostel_id)
    
    # Budget by category
    category_spending = {}
    categories = query.with_entities(MaintenanceCost.category).distinct().all()
    
    for (category,) in categories:
        total_spent = query.filter(MaintenanceCost.category == category).with_entities(
            func.sum(MaintenanceCost.amount)
        ).scalar() or 0
        
        pending_amount = query.filter(
            MaintenanceCost.category == category,
            MaintenanceCost.payment_status == "PENDING"
        ).with_entities(func.sum(MaintenanceCost.amount)).scalar() or 0
        
        category_spending[category] = {
            "total_spent": total_spent,
            "pending_payments": pending_amount,
            "paid_amount": total_spent - pending_amount
        }
    
    # Hostel-wise breakdown if not filtered by hostel
    hostel_breakdown = {}
    if not hostel_id:
        hostels = query.with_entities(MaintenanceCost.hostel_id).distinct().all()
        for (h_id,) in hostels:
            hostel_total = query.filter(MaintenanceCost.hostel_id == h_id).with_entities(
                func.sum(MaintenanceCost.amount)
            ).scalar() or 0
            hostel_breakdown[h_id] = hostel_total
    
    return {
        "year": current_year,
        "category_spending": category_spending,
        "hostel_breakdown": hostel_breakdown if not hostel_id else None,
        "total_budget_used": sum([cat["total_spent"] for cat in category_spending.values()])
    }

@router.get("/maintenance/analytics/dashboard")
def get_maintenance_dashboard(hostel_id: Optional[int] = None, days: int = 30,
                            db: Session = Depends(get_db), user=Depends(current_user)):
    """Comprehensive maintenance analytics dashboard"""
    if user.get("role") not in [Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    from datetime import timedelta
    from app.models.maintenance import MaintenanceCost, MaintenanceTask
    
    start_date = datetime.now() - timedelta(days=days)
    
    # Base queries
    request_query = db.query(MaintenanceRequest).filter(MaintenanceRequest.created_at >= start_date)
    cost_query = db.query(MaintenanceCost).filter(MaintenanceCost.created_at >= start_date)
    task_query = db.query(MaintenanceTask).join(MaintenanceRequest).filter(MaintenanceRequest.created_at >= start_date)
    
    if hostel_id:
        request_query = request_query.filter(MaintenanceRequest.hostel_id == hostel_id)
        cost_query = cost_query.filter(MaintenanceCost.hostel_id == hostel_id)
        task_query = task_query.filter(MaintenanceRequest.hostel_id == hostel_id)
    
    # Request metrics
    total_requests = request_query.count()
    pending_requests = request_query.filter(MaintenanceRequest.status == "PENDING").count()
    in_progress_requests = request_query.filter(MaintenanceRequest.status == "IN_PROGRESS").count()
    completed_requests = request_query.filter(MaintenanceRequest.status == "COMPLETED").count()
    high_priority_requests = request_query.filter(MaintenanceRequest.priority.in_(["HIGH", "URGENT"])).count()
    
    # Cost metrics
    total_cost = cost_query.with_entities(func.sum(MaintenanceCost.amount)).scalar() or 0
    pending_payments = cost_query.filter(MaintenanceCost.payment_status == "PENDING").with_entities(
        func.sum(MaintenanceCost.amount)
    ).scalar() or 0
    
    # Task metrics
    total_tasks = task_query.count()
    completed_tasks = task_query.filter(MaintenanceTask.status == "COMPLETED").count()
    overdue_tasks = task_query.filter(
        MaintenanceTask.scheduled_date < datetime.now(),
        MaintenanceTask.status.in_(["ASSIGNED", "IN_PROGRESS"])
    ).count()
    
    # Average completion time
    completed_with_dates = request_query.filter(
        MaintenanceRequest.status == "COMPLETED",
        MaintenanceRequest.completed_date.isnot(None)
    ).all()
    
    avg_completion_hours = 0
    if completed_with_dates:
        total_hours = sum([(r.completed_date - r.created_at).total_seconds() / 3600 for r in completed_with_dates])
        avg_completion_hours = total_hours / len(completed_with_dates)
    
    # Category breakdown
    category_breakdown = {}
    categories = request_query.with_entities(MaintenanceRequest.category).distinct().all()
    for (category,) in categories:
        count = request_query.filter(MaintenanceRequest.category == category).count()
        category_breakdown[category] = count
    
    return {
        "period_days": days,
        "requests": {
            "total": total_requests,
            "pending": pending_requests,
            "in_progress": in_progress_requests,
            "completed": completed_requests,
            "high_priority": high_priority_requests,
            "completion_rate": round((completed_requests / total_requests * 100) if total_requests > 0 else 0, 2)
        },
        "costs": {
            "total_spent": total_cost,
            "pending_payments": pending_payments,
            "paid_amount": total_cost - pending_payments
        },
        "tasks": {
            "total": total_tasks,
            "completed": completed_tasks,
            "overdue": overdue_tasks,
            "completion_rate": round((completed_tasks / total_tasks * 100) if total_tasks > 0 else 0, 2)
        },
        "performance": {
            "avg_completion_time_hours": round(avg_completion_hours, 2)
        },
        "category_breakdown": category_breakdown
    }

@router.get("/maintenance/reports/monthly")
def get_monthly_maintenance_report(year: int, month: int, hostel_id: Optional[int] = None,
                                 db: Session = Depends(get_db), user=Depends(current_user)):
    """Generate comprehensive monthly maintenance report"""
    if user.get("role") not in [Role.ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Forbidden")
    
    from calendar import monthrange
    from app.models.maintenance import MaintenanceCost
    
    # Date range for the month
    start_date = datetime(year, month, 1)
    last_day = monthrange(year, month)[1]
    end_date = datetime(year, month, last_day, 23, 59, 59)
    
    # Base queries
    request_query = db.query(MaintenanceRequest).filter(
        MaintenanceRequest.created_at >= start_date,
        MaintenanceRequest.created_at <= end_date
    )
    cost_query = db.query(MaintenanceCost).filter(
        MaintenanceCost.created_at >= start_date,
        MaintenanceCost.created_at <= end_date
    )
    
    if hostel_id:
        request_query = request_query.filter(MaintenanceRequest.hostel_id == hostel_id)
        cost_query = cost_query.filter(MaintenanceCost.hostel_id == hostel_id)
    
    # Summary statistics
    total_requests = request_query.count()
    total_cost = cost_query.with_entities(func.sum(MaintenanceCost.amount)).scalar() or 0
    
    # Priority distribution
    priority_dist = {}
    for priority in ["LOW", "MEDIUM", "HIGH", "URGENT"]:
        count = request_query.filter(MaintenanceRequest.priority == priority).count()
        priority_dist[priority] = count
    
    # Status distribution
    status_dist = {}
    for status in ["PENDING", "IN_PROGRESS", "COMPLETED", "REJECTED"]:
        count = request_query.filter(MaintenanceRequest.status == status).count()
        status_dist[status] = count
    
    # Top categories by cost
    category_costs = cost_query.with_entities(
        MaintenanceCost.category,
        func.sum(MaintenanceCost.amount).label('total_cost')
    ).group_by(MaintenanceCost.category).order_by(desc('total_cost')).limit(5).all()
    
    return {
        "report_period": f"{year}-{month:02d}",
        "summary": {
            "total_requests": total_requests,
            "total_cost": total_cost,
            "avg_cost_per_request": round(total_cost / total_requests, 2) if total_requests > 0 else 0
        },
        "priority_distribution": priority_dist,
        "status_distribution": status_dist,
        "top_categories_by_cost": [{"category": cat, "total_cost": cost} for cat, cost in category_costs]
    }