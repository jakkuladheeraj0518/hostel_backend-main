# FEATURE TO ENDPOINT MAPPING
## Based on System Requirements Image

**Reference:** System Requirements Image  
**Document:** 15_USER_EXAMPLES.md

---

## IMAGE FEATURE CATEGORIES

### A. REVIEWS & RATINGS SYSTEM
### B. MAINTENANCE MANAGEMENT  
### C. ADVANCED FEATURES

---

## COMPLETE FEATURE MAPPING

### 📊 REVIEWS & RATINGS SYSTEM

#### 1. Review Submission APIs
**Description:** APIs for verified visitors to submit ratings (1-5 stars), write reviews, upload photos

**Endpoints:**
- `POST /student/reviews/{hostel_id}` - Submit review with rating and photo
- `POST /visitor/reviews/{hostel_id}` - Anonymous review submission
- `PUT /student/reviews/{review_id}` - Update existing review
- `DELETE /student/reviews/{review_id}` - Delete own review

**User Example:** USER 1 (Student 1)

---

#### 2. Review Moderation APIs
**Description:** Admin review approval/rejection, spam detection, inappropriate content filtering

**Endpoints:**
- `GET /admin/reviews/pending` - Get reviews pending moderation
- `PUT /admin/reviews/{review_id}/moderate` - Approve/reject/mark spam
- `GET /admin/reviews/spam` - View spam reviews
- `GET /admin/reviews/analytics` - Review analytics dashboard

**User Example:** USER 2 (Admin 1)

---

#### 3. Review Display & Sorting APIs
**Description:** Display reviews with helpful voting, sort by recency/rating, aggregate rating calculations

**Endpoints:**
- `GET /visitor/hostels/{hostel_id}/reviews` - Get reviews with sorting
- `POST /student/reviews/{review_id}/helpful` - Mark review helpful
- `POST /visitor/reviews/{review_id}/helpful` - Visitor helpful vote
- `GET /visitor/hostels/{hostel_id}` - Get hostel with aggregate ratings
- `GET /visitor/reviews/stats` - Review statistics
- `GET /visitor/reviews/trending` - Trending reviews

**User Example:** USER 3 (Visitor)

---

### 🔧 MAINTENANCE MANAGEMENT

#### 4. Maintenance Request APIs
**Description:** Log maintenance requests with categorization, priority, status tracking, staff assignment

**Endpoints:**
- `POST /supervisor/maintenance/requests` - Create maintenance request
- `GET /supervisor/maintenance/requests` - List requests with filters
- `PUT /supervisor/maintenance/requests/{id}` - Update request
- `GET /admin/maintenance/requests` - Admin view all requests
- `PUT /admin/maintenance/requests/{id}/assign` - Assign to staff

**User Example:** USER 4 (Supervisor 1)

---

#### 5. Preventive Maintenance APIs
**Description:** Schedule recurring maintenance tasks, maintenance calendar, equipment lifecycle tracking

**Endpoints:**
- `POST /admin/preventive-maintenance/schedules` - Create schedule
- `GET /admin/preventive-maintenance/schedules` - List schedules
- `GET /admin/preventive-maintenance/due` - Get due maintenance
- `POST /admin/preventive-maintenance/tasks` - Create task
- `PUT /admin/preventive-maintenance/tasks/{id}` - Update task

**User Example:** USER 5 (Admin 1)

---

#### 6. Maintenance Cost Tracking APIs
**Description:** Budget allocation per hostel, cost tracking by category, vendor payment management

**Endpoints:**
- `POST /supervisor/maintenance/costs` - Record cost
- `GET /supervisor/maintenance/costs` - List costs with filters
- `PUT /supervisor/maintenance/costs/{id}/payment` - Update payment status
- `GET /supervisor/maintenance/budget/summary` - Budget summary
- `GET /admin/maintenance/costs` - Admin cost view

**User Example:** USER 6 (Supervisor 2)

---

#### 7. Maintenance Task Assignment
**Description:** Assign to staff/vendors, track progress, completion verification, quality checks

**Endpoints:**
- `POST /supervisor/maintenance/tasks` - Create and assign task
- `GET /supervisor/maintenance/tasks` - List tasks
- `PUT /supervisor/maintenance/tasks/{id}` - Update task with quality rating

**User Example:** USER 7 (Supervisor 3)

---

#### 8. Approval Workflow for High-Value Repairs
**Description:** Supervisor request submission, admin approval for threshold-exceeding repairs

**Endpoints:**
- `GET /supervisor/maintenance/requests/high-value` - View high-value requests
- `GET /admin/maintenance/requests/high-value` - Admin view
- `PUT /admin/maintenance/requests/{id}/approve` - Approve/reject

**User Example:** USER 8 (Admin 2)

---

### ⭐ ADVANCED FEATURES

#### 9. Preventive Maintenance Scheduler
**Description:** Recurring task setup, calendar management, supervisor execution tracking

**Endpoints:**
- `POST /admin/preventive-maintenance/schedules` - Setup recurring schedule
- `POST /admin/preventive-maintenance/tasks` - Create task for supervisor
- `PUT /admin/preventive-maintenance/tasks/{id}` - Track execution
- `GET /admin/preventive-maintenance/due` - Calendar view

**User Example:** USER 9 (Admin 1)

---

#### 10. Review & Rating System
**Description:** Student reviews, ratings, helpful voting, moderation, hostel rating aggregation

**Endpoints:**
- `POST /student/reviews/{hostel_id}` - Submit review
- `POST /student/reviews/{review_id}/helpful` - Helpful voting
- `GET /visitor/hostels/{hostel_id}` - Rating aggregation
- `PUT /admin/reviews/{review_id}/moderate` - Moderation

**User Example:** USER 10 (Student 2)

---

#### 11. Leave Application Management
**Description:** Student leave requests, supervisor approval workflows, leave balance tracking

**Endpoints:**
- `POST /student/leave/apply` - Submit leave request
- `GET /student/leave/balance` - Check leave balance
- `GET /student/leave/my` - View my requests
- `GET /supervisor/leave/requests` - View pending requests
- `PUT /supervisor/leave/requests/{id}/review` - Approve/reject

**User Examples:** USER 11 (Student 3), USER 12 (Supervisor 1)

---

## ADDITIONAL FEATURES (Not in Image but Implemented)

### Attendance Management
**Endpoints:**
- `POST /supervisor/attendance/mark` - Mark individual attendance
- `POST /supervisor/attendance/bulk-mark` - Bulk mark attendance
- `GET /supervisor/attendance/report` - Attendance report
- `GET /student/attendance/my` - Student view attendance

**User Examples:** USER 14 (Student 4), USER 15 (Supervisor 1)

---

### System Administration
**Endpoints:**
- `GET /super-admin/analytics/overview` - System-wide analytics
- `POST /super-admin/hostels` - Create hostel
- `POST /super-admin/users` - Create user
- `POST /super-admin/assign-admin-hostel` - Assign admin to hostel

**User Example:** USER 13 (Super Admin)

---

## ENDPOINT COUNT BY CATEGORY

| Category | Endpoints | Users |
|----------|-----------|-------|
| Reviews & Ratings | 12 | 3 |
| Maintenance Management | 18 | 5 |
| Advanced Features | 11 | 3 |
| Attendance | 4 | 2 |
| System Admin | 4 | 1 |
| Authentication | 2 | All |
| **TOTAL** | **51+** | **15** |

---

## TESTING COVERAGE

### ✅ All Features from Image Covered
- Review Submission APIs ✅
- Review Moderation APIs ✅
- Review Display & Sorting APIs ✅
- Maintenance Request APIs ✅
- Preventive Maintenance APIs ✅
- Maintenance Cost Tracking APIs ✅
- Maintenance Task Assignment ✅
- Approval Workflow for High-Value Repairs ✅
- Preventive Maintenance Scheduler ✅
- Review & Rating System ✅
- Leave Application Management ✅

### ✅ Bonus Features Included
- Attendance Management ✅
- System Administration ✅
- User Management ✅

---

## QUICK REFERENCE

**Main Document:** `15_USER_EXAMPLES.md`  
**API Documentation:** `API_ENDPOINTS_PARAMETERS_RESPONSES.md`  
**Testing Guide:** `API_TESTING_EXAMPLES.md`

**All endpoints tested with 15 different users**  
**All responses are successful (200 OK)**  
**Ready for QA and Frontend Integration**

---

**Created:** November 18, 2025  
**Status:** Complete & Verified  
**Based On:** System Requirements Image
