#!/usr/bin/env python3
"""
Hostel Management System Startup Script
=======================================

This script starts both the backend and frontend servers for development.

Usage:
    python start.py [--backend-only] [--frontend-only] [--port PORT]
"""

import os
import sys
import subprocess
import argparse
import time
import signal
from pathlib import Path

class ServerManager:
    def __init__(self):
        self.processes = []
        self.backend_port = 8000
        self.frontend_port = 3000
    
    def start_backend(self, port=None):
        """Start the FastAPI backend server."""
        if port:
            self.backend_port = port
            
        print(f"🚀 Starting backend server on port {self.backend_port}...")
        
        # Determine the correct python executable
        if os.name == 'nt':  # Windows
            python_cmd = ".venv\\Scripts\\python"
        else:  # Unix/Linux/macOS
            python_cmd = ".venv/bin/python"
        
        # Check if virtual environment exists
        if not os.path.exists(".venv"):
            print("❌ Virtual environment not found. Please run setup.py first.")
            return False
        
        try:
            # Start uvicorn server
            cmd = [
                python_cmd, "-m", "uvicorn", 
                "app.main:app", 
                "--reload", 
                "--host", "0.0.0.0",
                "--port", str(self.backend_port)
            ]
            
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                universal_newlines=True,
                bufsize=1
            )
            
            self.processes.append(("Backend", process))
            print(f"✅ Backend server started (PID: {process.pid})")
            print(f"   API: http://localhost:{self.backend_port}")
            print(f"   Docs: http://localhost:{self.backend_port}/docs")
            return True
            
        except Exception as e:
            print(f"❌ Failed to start backend: {e}")
            return False
    
    def start_frontend(self):
        """Start the React frontend server."""
        print(f"🎨 Starting frontend server on port {self.frontend_port}...")
        
        frontend_dir = Path("frontend")
        if not frontend_dir.exists():
            print("❌ Frontend directory not found.")
            return False
        
        # Check if node_modules exists
        if not (frontend_dir / "node_modules").exists():
            print("❌ Frontend dependencies not installed. Please run setup.py first.")
            return False
        
        try:
            # Start npm development server
            if os.name == 'nt':  # Windows
                cmd = ["npm.cmd", "start"]
            else:  # Unix/Linux/macOS
                cmd = ["npm", "start"]
            
            # Set environment variables
            env = os.environ.copy()
            env["BROWSER"] = "none"  # Don't auto-open browser
            env["PORT"] = str(self.frontend_port)
            
            process = subprocess.Popen(
                cmd,
                cwd=frontend_dir,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                universal_newlines=True,
                bufsize=1,
                env=env
            )
            
            self.processes.append(("Frontend", process))
            print(f"✅ Frontend server started (PID: {process.pid})")
            print(f"   App: http://localhost:{self.frontend_port}")
            return True
            
        except Exception as e:
            print(f"❌ Failed to start frontend: {e}")
            return False
    
    def monitor_processes(self):
        """Monitor running processes and display output."""
        print("\\n📊 Monitoring servers... (Press Ctrl+C to stop)")
        print("=" * 60)
        
        try:
            while True:
                for name, process in self.processes:
                    if process.poll() is not None:
                        print(f"❌ {name} server stopped unexpectedly")
                        return
                
                time.sleep(1)
                
        except KeyboardInterrupt:
            print("\\n🛑 Shutting down servers...")
            self.stop_all()
    
    def stop_all(self):
        """Stop all running processes."""
        for name, process in self.processes:
            try:
                print(f"Stopping {name} server...")
                if os.name == 'nt':  # Windows
                    process.terminate()
                else:  # Unix/Linux/macOS
                    process.send_signal(signal.SIGTERM)
                
                # Wait for graceful shutdown
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    print(f"Force killing {name} server...")
                    process.kill()
                    
            except Exception as e:
                print(f"Error stopping {name}: {e}")
        
        print("✅ All servers stopped")

def check_ports(backend_port, frontend_port):
    """Check if ports are available."""
    import socket
    
    def is_port_in_use(port):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            return s.connect_ex(('localhost', port)) == 0
    
    if is_port_in_use(backend_port):
        print(f"⚠️  Port {backend_port} is already in use")
        return False
    
    if is_port_in_use(frontend_port):
        print(f"⚠️  Port {frontend_port} is already in use")
        return False
    
    return True

def main():
    """Main startup function."""
    parser = argparse.ArgumentParser(description="Start Hostel Management System")
    parser.add_argument("--backend-only", action="store_true", help="Start only backend server")
    parser.add_argument("--frontend-only", action="store_true", help="Start only frontend server")
    parser.add_argument("--port", type=int, default=8000, help="Backend port (default: 8000)")
    
    args = parser.parse_args()
    
    print("🏠 Hostel Management System")
    print("=" * 40)
    
    manager = ServerManager()
    
    # Check port availability
    if not check_ports(args.port, 3000):
        print("❌ Required ports are not available")
        sys.exit(1)
    
    success = True
    
    # Start servers based on arguments
    if args.frontend_only:
        success = manager.start_frontend()
    elif args.backend_only:
        success = manager.start_backend(args.port)
    else:
        # Start both servers
        backend_success = manager.start_backend(args.port)
        time.sleep(2)  # Give backend time to start
        frontend_success = manager.start_frontend()
        success = backend_success and frontend_success
    
    if success:
        print("\\n🎉 All servers started successfully!")
        print("\\nDemo login credentials:")
        print("  Admin: admin@hostel.com / admin123")
        print("  Student: student@hostel.com / student123")
        print("  Supervisor: supervisor@hostel.com / supervisor123")
        
        manager.monitor_processes()
    else:
        print("❌ Failed to start servers")
        manager.stop_all()
        sys.exit(1)

if __name__ == "__main__":
    main()