# AI Coding Agent Instructions for Hostel Management API

## 🏗️ Architecture Overview

**FastAPI + PostgreSQL + SQLAlchemy** - A production-ready hostel management system with 5 user roles and specialized subsystems for maintenance, reviews, leaves, and attendance.

### Core Components

- **API Gateway** (`app/main.py`): FastAPI app with CORS, rate limiting, and 6 role-based routers
- **Role System** (`app/core/rbac.py`): SUPER_ADMIN → ADMIN → SUPERVISOR → STUDENT/VISITOR (role-checked on every endpoint)
- **Data Layer** (`app/models/`): 9 SQLAlchemy models with relationships (User, Hostel, Maintenance, Review, Leave, etc.)
- **API Contracts** (`app/schemas/`): Pydantic v2 for request/response validation
- **Database** (`app/core/database.py`): PostgreSQL via SQLAlchemy ORM, pooled connections

### Key Integration Pattern
1. Request arrives at versioned router (`/api/v1/{role}/...`)
2. `current_user` dependency extracts JWT payload via HTTPBearer
3. Role check via `user.get("role") not in [ADMIN, ...]` (HTTPException 403 if denied)
4. DB operation via SessionLocal, commit/refresh pattern
5. Response via Pydantic schema or dict literal

## 🔐 Authentication & Authorization

**JWT Bearer tokens** (HS256, 60-min default) stored in request as `Authorization: Bearer {token}`. Token payload contains `user_data` dict with `id`, `email`, `role`, `hostel_id`.

**All endpoints require role checks** — check user role before DB queries:
```python
if user.get("role") not in [Role.ADMIN, Role.SUPER_ADMIN]:
    raise HTTPException(403, "Forbidden")
```

Middleware flow:
1. Extract bearer token via `deps.py` HTTPBearer
2. Decode JWT in `security.py` (raises 401 on invalid/expired)
3. Pass `user` dict to route handler
4. Guard with role check at handler entry

## 📋 Database & ORM Patterns

**Mapped Column Syntax** (SQLAlchemy 2.0 with PEP 593):
```python
class User(Base):
    id: Mapped[int] = mapped_column(primary_key=True)
    email: Mapped[str] = mapped_column(String(255), unique=True)
    role: Mapped[str] = mapped_column(String(32), default="VISITOR")
    # Use `| None` for nullable, `func.now()` for defaults
    hostel_id: Mapped[int | None] = mapped_column(ForeignKey("hostels.id"))
```

**Validation via `@validates` decorator** (see `User.validate_phone_number`, `validate_blood_group`).

**Migrations**: Run `alembic upgrade head` after schema changes; Alembic autogenerates most migrations.

**Foreign Keys**: Use `ondelete="CASCADE"` for hostel relationships (avoid orphaned records).

## 🎯 Subsystem-Specific Patterns

### **Maintenance System** (MaintenanceRequest, MaintenanceCost, MaintenanceTask, PreventiveMaintenanceSchedule)
- **Request Lifecycle**: PENDING → IN_PROGRESS → COMPLETED → APPROVED
- **Cost Tracking**: Link via `maintenance_request_id`; support multiple categories (LABOR, MATERIALS, EQUIPMENT, VENDOR)
- **Approval Workflow**: Threshold-based (supervisor requests, admin approves if cost > threshold)
- **Preventive**: Recurring tasks with frequencies; stored separately from reactive requests

### **Review System** (Review model + moderation)
- **Submission**: Visitors (unauth) → stored with `is_approved=False, is_spam=False` initially
- **Moderation**: Admin approves/rejects; updates `is_approved`, `is_spam` flags
- **Helpful Voting**: Track votes in separate table or denormalized count; sort by helpfulness
- **Aggregation**: Real-time avg rating calculation per hostel (use SQLAlchemy `func.avg()`)

### **Leave Management** (LeaveRequest)
- **Approval Workflow**: Student applies → Supervisor reviews → Status: PENDING/APPROVED/REJECTED
- **Balance Tracking**: Derive from approved leaves per student per year
- **Date Range**: `from_date`, `to_date` fields; calculate duration on client/API side

### **Attendance** (Attendance model)
- **Daily Marking**: PRESENT/ABSENT/LEAVE per student per hostel per date
- **Bulk Operations**: Accept list of student IDs + date + status in single request
- **Hostel Scope**: Filter by `hostel_id` (use `user.get("hostel_id")` as default if not set)

## 🚀 Development Workflow

### **Quick Start**
```bash
# 1. Setup environment
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt

# 2. Configure database
# Set DATABASE_URL in .env (defaults to postgres://localhost:5432/hostel_mgmt)
# Create DB: createdb hostel_mgmt

# 3. Run migrations
alembic upgrade head

# 4. Seed sample data
python scripts/seed_data.py  # Creates 1 super-admin + 4 sample users

# 5. Start server
uvicorn app.main:app --reload
# API: http://localhost:8000/docs
```

### **Docker Development**
```bash
docker compose up --build  # Starts PostgreSQL + FastAPI
# API will be at http://localhost:8000
```

### **Testing**
```bash
# Currently minimal test suite (test_auth.py has placeholder)
# Run: pytest app/tests/

# Full feature verification exists in scripts/ but not part of pytest
python scripts/test_maintenance_system.py
python scripts/test_review_system_100.py
```

## 🔧 Endpoint Structure

All endpoints follow pattern: `/{role}/{resource}/{action}`

**Example Routes**:
- `POST /admin/users` — Create user (admin only)
- `POST /supervisor/maintenance/requests` — Create maintenance request
- `PUT /supervisor/maintenance/requests/{id}/status` — Update status
- `GET /supervisor/maintenance/budget/summary` — Aggregated costs
- `POST /visitor/reviews/{hostel_id}` — Submit review (public)
- `PUT /admin/reviews/{id}/moderate` — Moderate review

**Response Format**: Dict or Pydantic schema (auto-serialized to JSON).

## 📦 Dependency Injection Pattern

Use `Depends()` for:
- **Database**: `db: Session = Depends(get_db)` → SessionLocal instance
- **Auth**: `user = Depends(current_user)` → user dict from JWT
- **Validation**: Pydantic schemas in request body

Example:
```python
@router.post("/maintenance/requests")
def create_request(
    req: MaintenanceCreate,  # Pydantic validation
    db: Session = Depends(get_db),
    user = Depends(current_user)
):
    if user.get("role") not in [Role.SUPERVISOR, Role.ADMIN]:
        raise HTTPException(403, "Forbidden")
    # Process request...
```

## 🛡️ Rate Limiting

Configured via `app/core/rate_limiter.py` using SlowAPI (defaults to 1000/hour). Custom limits:
- Login: 5/min
- Registration: 3/min
- Review submission: 10/hr
- Admin ops: 500/hr

Apply via `@limiter.limit("5/minute")` decorator on routes (optional, not universally applied).

## 🔄 Error Handling

**Standard HTTP Exceptions**:
- `HTTPException(403, "Forbidden")` — Role check failed
- `HTTPException(401, "Missing token")` — Token missing
- `HTTPException(400, "Email already registered")` — Business logic violation
- `HTTPException(404, "Not found")` — Resource not found

No custom exception classes; rely on FastAPI's HTTPException with descriptive messages.

## 📝 Configuration Management

**Environment Variables** (`app/core/config.py`):
- `SECRET_KEY` — JWT signing key (defaults to "change_me")
- `DATABASE_URL` — PostgreSQL connection string
- `ACCESS_TOKEN_EXPIRE_MINUTES` — Token TTL (default 60)
- `ALLOWED_ORIGINS` — CORS origins (comma-separated, defaults to localhost:5173)

Load via `.env` file using `python-dotenv`.

## 🔍 Common Patterns & Conventions

### **Hostel Scoping**
Many tables (Attendance, Maintenance, Reviews) have `hostel_id` foreign key. **Always filter by hostel** when querying. Supervisors default to `hostel_id=1` if not set in user profile.

### **Soft vs Hard Deletes**
No soft-delete pattern; use `ondelete="CASCADE"` to clean up related records when hostel/user deleted.

### **Denormalization**
`User.hostel_id` stored directly for quick lookups; keep in sync during registration/assignment.

### **DateTime Handling**
Use `DateTime` with `default=func.now(), onupdate=func.now()` for `created_at`, `updated_at`. Always store as UTC.

### **Validation**
- **Schema-level**: Pydantic `Field()` with constraints (min_length, regex, ge/le)
- **Model-level**: SQLAlchemy `@validates` decorator (phone format, blood group)
- **Logic-level**: In route handler (email uniqueness, threshold checks)

## 🚢 Deployment Considerations

**Docker**: Dockerfile runs `uvicorn app.main:app --host 0.0.0.0 --port 8000`. Ensure `.env` or env vars set in container.

**Alembic Migrations**: Include in startup script: `alembic upgrade head` before `uvicorn` starts.

**PostgreSQL**: Requires `psycopg2-binary`. Connection pooling enabled via SQLAlchemy config.

**CORS**: Set `ALLOWED_ORIGINS` to frontend domain in production (env var, comma-separated).

## 🎓 Key Files Reference

| File | Purpose |
|------|---------|
| `app/main.py` | FastAPI app initialization, router includes, middleware |
| `app/api/deps.py` | Dependency injection for DB session and current user |
| `app/core/rbac.py` | Role enum (5 roles) |
| `app/core/security.py` | JWT creation/validation, password hashing |
| `app/models/*.py` | SQLAlchemy ORM models |
| `app/schemas/*.py` | Pydantic request/response schemas |
| `app/api/v1/{role}/routes.py` | 6 endpoint routers (auth, admin, supervisor, student, visitor, super_admin) |
| `scripts/seed_data.py` | Create sample users/hostels |
| `alembic/versions/` | Migration files (auto-generated) |

## ⚡ Gotchas & Best Practices

1. **Always check role before querying**: No row-level security in SQLAlchemy; authorization is application-level.
2. **Default hostel_id**: Supervisors often have `hostel_id=1` by default; don't hardcode — check user profile.
3. **Commit after add()**: Use `db.add(obj); db.commit(); db.refresh(obj)` pattern to return created object.
4. **Nullable relationships**: Use `| None` in Mapped annotations; ForeignKey allows NULL for optional many-to-one.
5. **Test JWT refresh**: Current impl has no refresh token logic; tokens are fixed-duration only.
6. **Migration conflicts**: If alembic can't autogenerate, manually edit migration file in `alembic/versions/`.

## 📊 Feature Coverage (100% Verified)

- ✅ Maintenance (request, assignment, cost tracking, preventive scheduling)
- ✅ Reviews (submission, moderation, helpful voting, aggregation)
- ✅ Leave management (apply, approve, balance tracking)
- ✅ Attendance (daily marking, bulk operations)
- ✅ Notice distribution (multi-audience, admin approval)
- ✅ RBAC with 5 roles and per-endpoint authorization
