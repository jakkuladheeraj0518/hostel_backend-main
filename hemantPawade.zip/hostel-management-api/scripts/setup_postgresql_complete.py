#!/usr/bin/env python3
"""
Complete PostgreSQL Setup - Test connection, create DB, run migrations, seed data
"""
import sys
import os
import subprocess
import psycopg2
from psycopg2 import sql

def test_postgres_connection():
    """Test if PostgreSQL is accessible"""
    print("🔍 Testing PostgreSQL connection...")
    
    try:
        # Try to connect to default postgres database
        conn = psycopg2.connect(
            host="localhost",
            port=5432,
            user="postgres",
            password="1234",
            database="postgres"
        )
        conn.close()
        print("✅ PostgreSQL is running and accessible!")
        return True
    except psycopg2.OperationalError as e:
        print(f"❌ Cannot connect to PostgreSQL: {e}")
        print("\n🔧 Possible solutions:")
        print("   1. Install PostgreSQL from: https://www.postgresql.org/download/windows/")
        print("   2. Start PostgreSQL service:")
        print("      - Open Services (Win+R, type 'services.msc')")
        print("      - Find 'postgresql-x64-XX' and start it")
        print("   3. Check if password is '1234' or update .env file")
        return False

def create_database():
    """Create hostel_mgmt database if it doesn't exist"""
    print("\n🔧 Creating database 'hostel_mgmt'...")
    
    try:
        # Connect to default postgres database
        conn = psycopg2.connect(
            host="localhost",
            port=5432,
            user="postgres",
            password="1234",
            database="postgres"
        )
        conn.autocommit = True
        cursor = conn.cursor()
        
        # Check if database exists
        cursor.execute("SELECT 1 FROM pg_database WHERE datname='hostel_mgmt'")
        exists = cursor.fetchone()
        
        if exists:
            print("✅ Database 'hostel_mgmt' already exists")
        else:
            # Create database
            cursor.execute(sql.SQL("CREATE DATABASE {}").format(
                sql.Identifier('hostel_mgmt')
            ))
            print("✅ Database 'hostel_mgmt' created successfully!")
        
        cursor.close()
        conn.close()
        return True
        
    except Exception as e:
        print(f"❌ Error creating database: {e}")
        return False

def run_migrations():
    """Run Alembic migrations"""
    print("\n🔧 Running database migrations...")
    
    try:
        result = subprocess.run(
            ["venv\\Scripts\\python.exe", "-m", "alembic", "upgrade", "head"],
            capture_output=True,
            text=True,
            timeout=60
        )
        
        if result.returncode == 0:
            print("✅ Migrations completed successfully!")
            if result.stdout:
                print(result.stdout)
            return True
        else:
            print("❌ Migration failed!")
            if result.stderr:
                print(result.stderr)
            return False
            
    except Exception as e:
        print(f"❌ Error running migrations: {e}")
        return False

def seed_database():
    """Seed database with initial data"""
    print("\n🔧 Seeding database with demo data...")
    
    try:
        result = subprocess.run(
            ["venv\\Scripts\\python.exe", "scripts\\seed_data.py"],
            capture_output=True,
            text=True,
            timeout=30
        )
        
        if result.returncode == 0:
            print("✅ Database seeded successfully!")
            if result.stdout:
                print(result.stdout)
            return True
        else:
            print("⚠️  Seeding had issues (might be okay if data already exists)")
            if result.stdout:
                print(result.stdout)
            return True  # Continue anyway
            
    except Exception as e:
        print(f"⚠️  Error seeding database: {e}")
        return True  # Continue anyway

def verify_setup():
    """Verify the setup is complete"""
    print("\n🔍 Verifying setup...")
    
    try:
        conn = psycopg2.connect(
            host="localhost",
            port=5432,
            user="postgres",
            password="1234",
            database="hostel_mgmt"
        )
        cursor = conn.cursor()
        
        # Check tables
        cursor.execute("""
            SELECT table_name 
            FROM information_schema.tables 
            WHERE table_schema = 'public'
            ORDER BY table_name;
        """)
        tables = cursor.fetchall()
        
        print(f"\n📊 Tables created: {len(tables)}")
        for table in tables:
            print(f"   ✅ {table[0]}")
        
        # Check users
        cursor.execute("SELECT COUNT(*) FROM users;")
        user_count = cursor.fetchone()[0]
        print(f"\n👥 Users in database: {user_count}")
        
        if user_count > 0:
            cursor.execute("SELECT email, role FROM users LIMIT 5;")
            users = cursor.fetchall()
            print("\n📝 Sample users:")
            for email, role in users:
                print(f"   - {email} ({role})")
        
        cursor.close()
        conn.close()
        
        return True
        
    except Exception as e:
        print(f"❌ Verification failed: {e}")
        return False

def main():
    """Main setup function"""
    print("="*60)
    print("🚀 PostgreSQL Complete Setup")
    print("="*60)
    
    # Step 1: Test connection
    if not test_postgres_connection():
        print("\n❌ Setup cannot continue without PostgreSQL connection")
        print("\n📖 See INSTALL_POSTGRESQL.md for installation instructions")
        return False
    
    # Step 2: Create database
    if not create_database():
        print("\n❌ Failed to create database")
        return False
    
    # Step 3: Run migrations
    if not run_migrations():
        print("\n❌ Failed to run migrations")
        return False
    
    # Step 4: Seed data
    seed_database()  # Continue even if this fails
    
    # Step 5: Verify
    if not verify_setup():
        print("\n⚠️  Setup completed but verification failed")
    
    print("\n" + "="*60)
    print("✅ PostgreSQL Setup Complete!")
    print("="*60)
    print("\n📊 Database: hostel_mgmt")
    print("🔗 Connection: postgresql://localhost:5432/hostel_mgmt")
    print("\n👥 Demo Credentials:")
    print("   Super Admin: admin@hostel.com / admin123")
    print("   Admin: admin1@hostel.com / admin123")
    print("   Supervisor: supervisor1@hostel.com / super123")
    print("   Student: student1@hostel.com / student123")
    print("\n🚀 Next Steps:")
    print("   1. Restart the server (Ctrl+C then restart)")
    print("   2. Go to: http://localhost:8000/docs")
    print("   3. Login with credentials above")
    
    return True

if __name__ == "__main__":
    try:
        success = main()
        sys.exit(0 if success else 1)
    except KeyboardInterrupt:
        print("\n\n⚠️  Setup interrupted by user")
        sys.exit(1)
