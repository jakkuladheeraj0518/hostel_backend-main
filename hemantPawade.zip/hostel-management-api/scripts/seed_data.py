import sys
import os
from datetime import datetime, date, timedelta
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from sqlalchemy.orm import Session
from app.core.database import SessionLocal
from app.models.user import User
from app.models.hostel import Hostel, AdminHostel, Supervisor
from app.models.review import Review
from app.models.maintenance import MaintenanceRequest, Complaint, MaintenanceCost, MaintenanceTask
from app.models.leave import LeaveRequest
from app.models.notice import Notice
from app.models.attendance import Attendance
from app.models.preventive_maintenance import PreventiveMaintenanceSchedule, PreventiveMaintenanceTask
from app.core.security import hash_password

def seed_database():
    db: Session = SessionLocal()
    
    try:
        print("🌱 Starting database seeding...")
        
        # 1. CREATE USERS
        print("\n👥 Creating users...")
        users_data = [
            {"email": "admin@hostel.com", "name": "Super Admin", "role": "SUPER_ADMIN", "password": "admin123"},
            {"email": "admin1@hostel.com", "name": "John Admin", "role": "ADMIN", "password": "admin123"},
            {"email": "admin2@hostel.com", "name": "Sarah Admin", "role": "ADMIN", "password": "admin123"},
            {"email": "supervisor1@hostel.com", "name": "Jane Supervisor", "role": "SUPERVISOR", "password": "super123"},
            {"email": "supervisor2@hostel.com", "name": "Mike Supervisor", "role": "SUPERVISOR", "password": "super123"},
            {"email": "student1@hostel.com", "name": "Bob Student", "role": "STUDENT", "password": "student123"},
            {"email": "student2@hostel.com", "name": "Alice Student", "role": "STUDENT", "password": "student123"},
            {"email": "student3@hostel.com", "name": "Charlie Student", "role": "STUDENT", "password": "student123"},
            {"email": "student4@hostel.com", "name": "Diana Student", "role": "STUDENT", "password": "student123"},
            {"email": "student5@hostel.com", "name": "Eve Student", "role": "STUDENT", "password": "student123"},
            {"email": "visitor@hostel.com", "name": "Guest Visitor", "role": "VISITOR", "password": "visitor123"},
        ]
        
        users = {}
        for user_data in users_data:
            if not db.query(User).filter(User.email == user_data["email"]).first():
                user = User(
                    email=user_data["email"],
                    full_name=user_data["name"],
                    role=user_data["role"],
                    hashed_password=hash_password(user_data["password"]),
                    is_active=True
                )
                db.add(user)
                db.flush()
                users[user_data["role"] + "_" + user_data["email"]] = user
                print(f"✅ Created {user_data['role']}: {user_data['email']} / {user_data['password']}")
        
        db.commit()
        
        # Refresh users dict
        users = {
            "super_admin": db.query(User).filter(User.email == "admin@hostel.com").first(),
            "admin1": db.query(User).filter(User.email == "admin1@hostel.com").first(),
            "admin2": db.query(User).filter(User.email == "admin2@hostel.com").first(),
            "supervisor1": db.query(User).filter(User.email == "supervisor1@hostel.com").first(),
            "supervisor2": db.query(User).filter(User.email == "supervisor2@hostel.com").first(),
            "student1": db.query(User).filter(User.email == "student1@hostel.com").first(),
            "student2": db.query(User).filter(User.email == "student2@hostel.com").first(),
            "student3": db.query(User).filter(User.email == "student3@hostel.com").first(),
            "student4": db.query(User).filter(User.email == "student4@hostel.com").first(),
            "student5": db.query(User).filter(User.email == "student5@hostel.com").first(),
        }
        
        # 2. CREATE HOSTELS
        print("\n🏠 Creating hostels...")
        hostels_data = [
            {"name": "Sunrise Hostel"},
            {"name": "Green Valley Hostel"},
            {"name": "City Center Hostel"}
        ]
        
        hostels = []
        for hostel_data in hostels_data:
            if not db.query(Hostel).filter(Hostel.name == hostel_data["name"]).first():
                hostel = Hostel(name=hostel_data["name"])
                db.add(hostel)
                db.flush()
                hostels.append(hostel)
                print(f"✅ Created hostel: {hostel_data['name']}")
        
        db.commit()
        
        # Refresh hostels
        hostel1 = db.query(Hostel).filter(Hostel.name == "Sunrise Hostel").first()
        hostel2 = db.query(Hostel).filter(Hostel.name == "Green Valley Hostel").first()
        hostel3 = db.query(Hostel).filter(Hostel.name == "City Center Hostel").first()
        
        # 3. ASSIGN ADMINS TO HOSTELS
        print("\n🔗 Assigning admins to hostels...")
        if not db.query(AdminHostel).first():
            admin_assignments = [
                AdminHostel(admin_id=users["admin1"].id, hostel_id=hostel1.id),
                AdminHostel(admin_id=users["admin2"].id, hostel_id=hostel2.id),
            ]
            for assignment in admin_assignments:
                db.add(assignment)
            db.commit()
            print("✅ Assigned admins to hostels")
        
        # 4. ASSIGN SUPERVISORS TO HOSTELS
        print("\n👷 Assigning supervisors to hostels...")
        if not db.query(Supervisor).first():
            supervisor_assignments = [
                Supervisor(user_id=users["supervisor1"].id, hostel_id=hostel1.id),
                Supervisor(user_id=users["supervisor2"].id, hostel_id=hostel2.id),
            ]
            for assignment in supervisor_assignments:
                db.add(assignment)
            db.commit()
            print("✅ Assigned supervisors to hostels")
        
        # 5. CREATE REVIEWS
        print("\n⭐ Creating reviews...")
        if not db.query(Review).first():
            reviews_data = [
                {"hostel_id": hostel1.id, "student_id": users["student1"].id, "rating": 5, "text": "Excellent hostel! Clean rooms and friendly staff.", "is_approved": True, "is_spam": False},
                {"hostel_id": hostel1.id, "student_id": users["student2"].id, "rating": 4, "text": "Great facilities and good location.", "is_approved": True, "is_spam": False},
                {"hostel_id": hostel1.id, "student_id": users["student3"].id, "rating": 3, "text": "Average experience, could be better.", "is_approved": False, "is_spam": False},
                {"hostel_id": hostel2.id, "student_id": users["student4"].id, "rating": 5, "text": "Amazing place to stay! Highly recommended.", "is_approved": True, "is_spam": False},
                {"hostel_id": hostel2.id, "student_id": users["student5"].id, "rating": 4, "text": "Good hostel with nice amenities.", "is_approved": False, "is_spam": False},
                {"hostel_id": hostel3.id, "student_id": users["student1"].id, "rating": 2, "text": "Not satisfied with the service.", "is_approved": True, "is_spam": False},
            ]
            
            for review_data in reviews_data:
                review = Review(**review_data, helpful_count=0)
                db.add(review)
            db.commit()
            print(f"✅ Created {len(reviews_data)} reviews")
        
        # 6. CREATE MAINTENANCE REQUESTS
        print("\n🔧 Creating maintenance requests...")
        if not db.query(MaintenanceRequest).first():
            maintenance_data = [
                {"hostel_id": hostel1.id, "created_by_id": users["supervisor1"].id, "category": "PLUMBING", "priority": "HIGH", "status": "PENDING", "description": "Leaking pipe in room 101", "est_cost": 500.00, "approved": False},
                {"hostel_id": hostel1.id, "created_by_id": users["supervisor1"].id, "category": "ELECTRICAL", "priority": "URGENT", "status": "IN_PROGRESS", "description": "Faulty wiring in corridor", "est_cost": 1500.00, "approved": True},
                {"hostel_id": hostel1.id, "created_by_id": users["supervisor1"].id, "category": "CARPENTRY", "priority": "MEDIUM", "status": "COMPLETED", "description": "Broken door in room 205", "est_cost": 300.00, "actual_cost": 280.00, "approved": True, "completed_date": datetime.now() - timedelta(days=2)},
                {"hostel_id": hostel2.id, "created_by_id": users["supervisor2"].id, "category": "PAINTING", "priority": "LOW", "status": "PENDING", "description": "Repaint common area", "est_cost": 2000.00, "approved": False},
                {"hostel_id": hostel2.id, "created_by_id": users["supervisor2"].id, "category": "PLUMBING", "priority": "HIGH", "status": "APPROVED", "description": "Bathroom renovation", "est_cost": 5000.00, "approved": True},
            ]
            
            for maint_data in maintenance_data:
                maintenance = MaintenanceRequest(**maint_data)
                db.add(maintenance)
            db.commit()
            print(f"✅ Created {len(maintenance_data)} maintenance requests")
        
        # 7. CREATE MAINTENANCE COSTS
        print("\n💰 Creating maintenance costs...")
        if not db.query(MaintenanceCost).first():
            maint_request = db.query(MaintenanceRequest).filter(MaintenanceRequest.status == "COMPLETED").first()
            if maint_request:
                costs_data = [
                    {"maintenance_request_id": maint_request.id, "hostel_id": maint_request.hostel_id, "category": "CARPENTRY", "vendor_name": "ABC Carpentry", "description": "Door replacement", "amount": 280.00, "payment_status": "PAID", "payment_method": "BANK_TRANSFER"},
                ]
                
                for cost_data in costs_data:
                    cost = MaintenanceCost(**cost_data)
                    db.add(cost)
                db.commit()
                print(f"✅ Created {len(costs_data)} maintenance costs")
        
        # 8. CREATE MAINTENANCE TASKS
        print("\n📋 Creating maintenance tasks...")
        if not db.query(MaintenanceTask).first():
            maint_request = db.query(MaintenanceRequest).filter(MaintenanceRequest.status == "IN_PROGRESS").first()
            if maint_request:
                tasks_data = [
                    {"maintenance_request_id": maint_request.id, "assigned_to_id": users["supervisor1"].id, "task_title": "Fix electrical wiring", "task_description": "Replace faulty wiring", "priority": "URGENT", "status": "IN_PROGRESS", "estimated_hours": 4},
                ]
                
                for task_data in tasks_data:
                    task = MaintenanceTask(**task_data, scheduled_date=date.today() + timedelta(days=1))
                    db.add(task)
                db.commit()
                print(f"✅ Created {len(tasks_data)} maintenance tasks")
        
        # 9. CREATE PREVENTIVE MAINTENANCE SCHEDULES
        print("\n🗓️ Creating preventive maintenance schedules...")
        if not db.query(PreventiveMaintenanceSchedule).first():
            schedules_data = [
                {"hostel_id": hostel1.id, "equipment_type": "AC_UNIT", "maintenance_type": "CLEANING", "frequency_days": 90, "next_due": date.today() + timedelta(days=30)},
                {"hostel_id": hostel1.id, "equipment_type": "WATER_HEATER", "maintenance_type": "INSPECTION", "frequency_days": 180, "next_due": date.today() + timedelta(days=60)},
                {"hostel_id": hostel2.id, "equipment_type": "ELEVATOR", "maintenance_type": "SERVICING", "frequency_days": 30, "next_due": date.today() + timedelta(days=5)},
            ]
            
            for schedule_data in schedules_data:
                schedule = PreventiveMaintenanceSchedule(**schedule_data, is_active=True)
                db.add(schedule)
            db.commit()
            print(f"✅ Created {len(schedules_data)} preventive maintenance schedules")
        
        # 10. CREATE COMPLAINTS
        print("\n📢 Creating complaints...")
        if not db.query(Complaint).first():
            complaints_data = [
                {"hostel_id": hostel1.id, "student_id": users["student1"].id, "category": "NOISE", "priority": "MEDIUM", "status": "PENDING", "description": "Loud music from neighboring room"},
                {"hostel_id": hostel1.id, "student_id": users["student2"].id, "category": "CLEANLINESS", "priority": "HIGH", "status": "IN_PROGRESS", "description": "Bathroom not cleaned properly"},
                {"hostel_id": hostel2.id, "student_id": users["student4"].id, "category": "SAFETY", "priority": "URGENT", "status": "RESOLVED", "description": "Broken lock on main door"},
            ]
            
            for complaint_data in complaints_data:
                complaint = Complaint(**complaint_data)
                db.add(complaint)
            db.commit()
            print(f"✅ Created {len(complaints_data)} complaints")
        
        # 11. CREATE LEAVE REQUESTS
        print("\n🏖️ Creating leave requests...")
        if not db.query(LeaveRequest).first():
            leave_data = [
                {"hostel_id": hostel1.id, "student_id": users["student1"].id, "start_date": date.today() + timedelta(days=10), "end_date": date.today() + timedelta(days=15), "reason": "Family wedding", "status": "PENDING"},
                {"hostel_id": hostel1.id, "student_id": users["student2"].id, "start_date": date.today() + timedelta(days=20), "end_date": date.today() + timedelta(days=25), "reason": "Medical appointment", "status": "APPROVED"},
                {"hostel_id": hostel2.id, "student_id": users["student4"].id, "start_date": date.today() - timedelta(days=5), "end_date": date.today() - timedelta(days=1), "reason": "Home visit", "status": "APPROVED"},
            ]
            
            for leave in leave_data:
                leave_request = LeaveRequest(**leave)
                db.add(leave_request)
            db.commit()
            print(f"✅ Created {len(leave_data)} leave requests")
        
        # 12. CREATE NOTICES
        print("\n📰 Creating notices...")
        if not db.query(Notice).first():
            notices_data = [
                {"hostel_id": hostel1.id, "title": "Maintenance Schedule", "content": "Water supply will be interrupted on Nov 15th from 9 AM to 2 PM", "audience": "ALL"},
                {"hostel_id": hostel1.id, "title": "New Rules", "content": "Please maintain silence after 10 PM", "audience": "STUDENTS"},
                {"hostel_id": hostel2.id, "title": "Holiday Notice", "content": "Hostel will be closed for cleaning on Dec 25th", "audience": "ALL"},
            ]
            
            for notice_data in notices_data:
                notice = Notice(**notice_data)
                db.add(notice)
            db.commit()
            print(f"✅ Created {len(notices_data)} notices")
        
        # 13. CREATE ATTENDANCE RECORDS
        print("\n📊 Creating attendance records...")
        if not db.query(Attendance).first():
            attendance_data = []
            for i in range(7):  # Last 7 days
                attendance_date = date.today() - timedelta(days=i)
                for student in [users["student1"], users["student2"], users["student3"]]:
                    status = "PRESENT" if i % 3 != 0 else "ABSENT"
                    attendance_data.append({
                        "hostel_id": hostel1.id,
                        "student_id": student.id,
                        "date": attendance_date,
                        "status": status
                    })
            
            for att_data in attendance_data:
                attendance = Attendance(**att_data)
                db.add(attendance)
            db.commit()
            print(f"✅ Created {len(attendance_data)} attendance records")
        
        print("\n✅ Database seeding completed successfully!")
        print("\n📝 Login Credentials:")
        print("=" * 50)
        print("Super Admin: admin@hostel.com / admin123")
        print("Admin: admin1@hostel.com / admin123")
        print("Supervisor: supervisor1@hostel.com / super123")
        print("Student: student1@hostel.com / student123")
        print("Visitor: visitor@hostel.com / visitor123")
        print("=" * 50)
        
    except Exception as e:
        print(f"\n❌ Error during seeding: {e}")
        db.rollback()
        raise
    finally:
        db.close()

if __name__ == "__main__":
    seed_database()
