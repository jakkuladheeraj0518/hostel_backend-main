#!/usr/bin/env python3
"""
Hostel Management System Setup Script
=====================================

This script sets up the complete Hostel Management System including:
- Backend API with FastAPI
- Frontend React application
- Database initialization
- Sample data creation

Usage:
    python setup.py [--skip-frontend] [--skip-backend] [--skip-data]
"""

import os
import sys
import subprocess
import argparse
from pathlib import Path

def run_command(command, cwd=None, check=True):
    """Run a shell command and handle errors."""
    print(f"Running: {command}")
    try:
        result = subprocess.run(
            command, 
            shell=True, 
            cwd=cwd, 
            check=check,
            capture_output=True,
            text=True
        )
        if result.stdout:
            print(result.stdout)
        return result
    except subprocess.CalledProcessError as e:
        print(f"Error running command: {command}")
        print(f"Error output: {e.stderr}")
        if check:
            sys.exit(1)
        return e

def check_requirements():
    """Check if required tools are installed."""
    print("🔍 Checking requirements...")
    
    # Check Python
    try:
        python_version = subprocess.check_output([sys.executable, "--version"], text=True)
        print(f"✅ Python: {python_version.strip()}")
    except:
        print("❌ Python not found")
        sys.exit(1)
    
    # Check Node.js
    try:
        node_version = subprocess.check_output(["node", "--version"], text=True)
        print(f"✅ Node.js: {node_version.strip()}")
    except:
        print("❌ Node.js not found. Please install Node.js 16+ from https://nodejs.org/")
        sys.exit(1)
    
    # Check npm
    try:
        npm_version = subprocess.check_output(["npm", "--version"], text=True)
        print(f"✅ npm: {npm_version.strip()}")
    except:
        print("❌ npm not found")
        sys.exit(1)

def setup_backend():
    """Set up the FastAPI backend."""
    print("\n🚀 Setting up Backend...")
    
    # Create virtual environment if it doesn't exist
    if not os.path.exists(".venv"):
        print("Creating virtual environment...")
        run_command(f"{sys.executable} -m venv .venv")
    
    # Activate virtual environment and install dependencies
    if os.name == 'nt':  # Windows
        pip_cmd = ".venv\\Scripts\\pip"
        python_cmd = ".venv\\Scripts\\python"
    else:  # Unix/Linux/macOS
        pip_cmd = ".venv/bin/pip"
        python_cmd = ".venv/bin/python"
    
    print("Installing Python dependencies...")
    run_command(f"{pip_cmd} install --upgrade pip")
    run_command(f"{pip_cmd} install -r requirements.txt")
    
    # Set up database
    print("Setting up database...")
    run_command(f"{python_cmd} -c \"from app.database import init_db; init_db()\"")
    
    # Run migrations
    print("Running database migrations...")
    run_command("alembic upgrade head")
    
    print("✅ Backend setup complete!")

def setup_frontend():
    """Set up the React frontend."""
    print("\n🎨 Setting up Frontend...")
    
    frontend_dir = Path("frontend")
    if not frontend_dir.exists():
        print("❌ Frontend directory not found")
        return
    
    # Install npm dependencies
    print("Installing npm dependencies...")
    run_command("npm install", cwd=frontend_dir)
    
    print("✅ Frontend setup complete!")

def create_sample_data():
    """Create sample data for testing."""
    print("\n📊 Creating sample data...")
    
    if os.name == 'nt':  # Windows
        python_cmd = ".venv\\Scripts\\python"
    else:  # Unix/Linux/macOS
        python_cmd = ".venv/bin/python"
    
    # Create sample data script
    sample_script = """
from app.database import get_db
from app.models.user import User
from app.models.hostel import Hostel
from app.models.maintenance import MaintenanceRequest
from app.models.review import Review
from app.core.security import get_password_hash
from sqlalchemy.orm import Session
import datetime

def create_sample_data():
    db = next(get_db())
    
    # Create sample users
    users = [
        {
            "email": "admin@hostel.com",
            "password": get_password_hash("admin123"),
            "full_name": "Admin User",
            "role": "ADMIN",
            "is_active": True
        },
        {
            "email": "student@hostel.com", 
            "password": get_password_hash("student123"),
            "full_name": "John Student",
            "role": "STUDENT",
            "is_active": True
        },
        {
            "email": "supervisor@hostel.com",
            "password": get_password_hash("supervisor123"), 
            "full_name": "Jane Supervisor",
            "role": "SUPERVISOR",
            "is_active": True
        }
    ]
    
    for user_data in users:
        existing = db.query(User).filter(User.email == user_data["email"]).first()
        if not existing:
            user = User(**user_data)
            db.add(user)
    
    # Create sample hostels
    hostels = [
        {
            "name": "Sunrise Hostel",
            "description": "A beautiful hostel with great amenities",
            "capacity": 100,
            "current_occupancy": 85
        },
        {
            "name": "Mountain View Hostel", 
            "description": "Hostel with stunning mountain views",
            "capacity": 150,
            "current_occupancy": 120
        }
    ]
    
    for hostel_data in hostels:
        existing = db.query(Hostel).filter(Hostel.name == hostel_data["name"]).first()
        if not existing:
            hostel = Hostel(**hostel_data)
            db.add(hostel)
    
    db.commit()
    print("✅ Sample data created successfully!")

if __name__ == "__main__":
    create_sample_data()
"""
    
    # Write and run sample data script
    with open("create_sample_data.py", "w") as f:
        f.write(sample_script)
    
    run_command(f"{python_cmd} create_sample_data.py")
    
    # Clean up
    os.remove("create_sample_data.py")

def main():
    """Main setup function."""
    parser = argparse.ArgumentParser(description="Setup Hostel Management System")
    parser.add_argument("--skip-frontend", action="store_true", help="Skip frontend setup")
    parser.add_argument("--skip-backend", action="store_true", help="Skip backend setup") 
    parser.add_argument("--skip-data", action="store_true", help="Skip sample data creation")
    
    args = parser.parse_args()
    
    print("🏠 Hostel Management System Setup")
    print("=" * 40)
    
    check_requirements()
    
    if not args.skip_backend:
        setup_backend()
    
    if not args.skip_frontend:
        setup_frontend()
    
    if not args.skip_data:
        create_sample_data()
    
    print("\n🎉 Setup Complete!")
    print("\nNext steps:")
    print("1. Start the backend:")
    if os.name == 'nt':
        print("   .venv\\Scripts\\python -m uvicorn app.main:app --reload")
    else:
        print("   .venv/bin/python -m uvicorn app.main:app --reload")
    
    print("\n2. Start the frontend (in a new terminal):")
    print("   cd frontend")
    print("   npm start")
    
    print("\n3. Open your browser:")
    print("   Backend API: http://localhost:8000")
    print("   Frontend App: http://localhost:3000")
    print("   API Docs: http://localhost:8000/docs")
    
    print("\n4. Demo login credentials:")
    print("   Admin: admin@hostel.com / admin123")
    print("   Student: student@hostel.com / student123") 
    print("   Supervisor: supervisor@hostel.com / supervisor123")

if __name__ == "__main__":
    main()