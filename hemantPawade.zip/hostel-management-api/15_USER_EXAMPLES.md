# 15 USER EXAMPLES - ORGANIZED BY FEATURE CATEGORIES
## Based on System Requirements Image

**Base URL:** `http://localhost:8000`

---

## FEATURE CATEGORIES (From Image)

### A. REVIEWS & RATINGS SYSTEM
1. Review Submission APIs
2. Review Moderation APIs
3. Review Display & Sorting APIs

### B. MAINTENANCE MANAGEMENT
4. Maintenance Request APIs
5. Preventive Maintenance APIs
6. Maintenance Cost Tracking APIs
7. Maintenance Task Assignment
8. Approval Workflow for High-Value Repairs

### C. ADVANCED FEATURES
9. Preventive Maintenance Scheduler
10. Review & Rating System
11. Leave Application Management

---

## SECTION 1: REVIEWS & RATINGS SYSTEM

### USER 1: STUDENT - Review Submission (1-5 Stars, Write Reviews, Upload Photos)

**User:** Student 1  
**Email:** student1@hostel.com  
**Password:** student123  
**Feature:** Review Submission APIs

#### Step 1: Login
**POST** `/auth/login`
```json
Request: {"email": "student1@hostel.com", "password": "student123"}
Response: {"access_token": "eyJ...", "expires_in": 3600}
```

#### Step 2: Submit Review with Photo
**POST** `/student/reviews/1`  
**Headers:** `Authorization: Bearer <token>`
```json
Request: {
  "rating": 5,
  "text": "Excellent hostel! Clean rooms, friendly staff, great amenities.",
  "photo_url": "https://example.com/room-photo.jpg"
}
Response: {
  "id": 25,
  "message": "Review submitted and approved",
  "auto_approved": true
}
```

---

### USER 2: ADMIN - Review Moderation (Approval/Rejection, Spam Detection)

**User:** Admin 1  
**Email:** admin1@hostel.com  
**Password:** admin123  
**Feature:** Review Moderation APIs

#### Step 1: Login
**POST** `/auth/login`
```json
Request: {"email": "admin1@hostel.com", "password": "admin123"}
Response: {"access_token": "eyJ...", "expires_in": 3600}
```

#### Step 2: Get Pending Reviews
**GET** `/admin/reviews/pending`  
**Headers:** `Authorization: Bearer <token>`
```json
Response: {
  "reviews": [{
    "id": 15,
    "hostel_id": 1,
    "rating": 4,
    "text": "Great hostel with excellent facilities",
    "created_at": "2025-11-10T08:30:00Z"
  }]
}
```

#### Step 3: Approve Review
**PUT** `/admin/reviews/15/moderate?action=approve`  
**Headers:** `Authorization: Bearer <token>`
```json
Response: {"ok": true, "action": "approve"}
```

#### Step 4: Mark Spam Review
**PUT** `/admin/reviews/20/moderate?action=mark_spam`  
**Headers:** `Authorization: Bearer <token>`
```json
Response: {"ok": true, "action": "mark_spam"}
```

---

### USER 3: VISITOR - Review Display & Sorting (Helpful Voting, Sort by Recency/Rating)

**User:** Visitor (No Login Required)  
**Feature:** Review Display & Sorting APIs

#### Step 1: Get Reviews Sorted by Most Helpful
**GET** `/visitor/hostels/1/reviews?sort_by=most_helpful&limit=10`
```json
Response: {
  "reviews": [{
    "id": 25,
    "rating": 5,
    "text": "Excellent hostel! Clean rooms...",
    "helpful_count": 12,
    "created_at": "2025-11-15T10:30:00Z"
  }]
}
```

#### Step 2: Mark Review as Helpful
**POST** `/visitor/reviews/25/helpful`
```json
Response: {"ok": true, "helpful_count": 13}
```

#### Step 3: Get Aggregate Rating Calculations
**GET** `/visitor/hostels/1`
```json
Response: {
  "id": 1,
  "name": "Sunrise Hostel",
  "avg_rating": 4.2,
  "review_count": 45,
  "rating_distribution": {
    "1_star": 2, "2_star": 3, "3_star": 8,
    "4_star": 15, "5_star": 17
  }
}
```

---

## SECTION 2: MAINTENANCE MANAGEMENT

### USER 4: SUPERVISOR - Maintenance Request (Log with Categorization, Priority, Status)

**User:** Supervisor 1  
**Email:** supervisor1@hostel.com  
**Password:** super123  
**Feature:** Maintenance Request APIs

#### Step 1: Login
**POST** `/auth/login`
```json
Request: {"email": "supervisor1@hostel.com", "password": "super123"}
Response: {"access_token": "eyJ...", "expires_in": 3600}
```

#### Step 2: Create Maintenance Request with Photo
**POST** `/supervisor/maintenance/requests`  
**Headers:** `Authorization: Bearer <token>`
```json
Request: {
  "category": "PLUMBING",
  "priority": "HIGH",
  "description": "Leaking pipe in room 205",
  "photo_url": "https://example.com/leak.jpg",
  "est_cost": 750.00,
  "scheduled_date": "2025-11-20"
}
Response: {
  "id": 12,
  "message": "Request created and approved",
  "requires_approval": false
}
```

#### Step 3: Track Request Status
**GET** `/supervisor/maintenance/requests?status=PENDING`  
**Headers:** `Authorization: Bearer <token>`
```json
Response: {
  "requests": [{
    "id": 12,
    "category": "PLUMBING",
    "priority": "HIGH",
    "status": "PENDING",
    "description": "Leaking pipe in room 205",
    "est_cost": 750.00
  }]
}
```

---

### USER 5: ADMIN - Preventive Maintenance (Schedule Recurring Tasks, Calendar)

**User:** Admin 1  
**Email:** admin1@hostel.com  
**Password:** admin123  
**Feature:** Preventive Maintenance APIs

#### Step 1: Login
**POST** `/auth/login`
```json
Request: {"email": "admin1@hostel.com", "password": "admin123"}
Response: {"access_token": "eyJ...", "expires_in": 3600}
```

#### Step 2: Create Preventive Maintenance Schedule
**POST** `/admin/preventive-maintenance/schedules`  
**Headers:** `Authorization: Bearer <token>`
```json
Request: {
  "hostel_id": 1,
  "equipment_type": "AC_UNIT",
  "maintenance_type": "CLEANING",
  "frequency_days": 90,
  "next_due": "2025-12-01"
}
Response: {"id": 3}
```

#### Step 3: Get Due Maintenance Tasks
**GET** `/admin/preventive-maintenance/due?days_ahead=7`  
**Headers:** `Authorization: Bearer <token>`
```json
Response: {
  "due_schedules": [{
    "id": 3,
    "hostel_id": 1,
    "equipment_type": "AC_UNIT",
    "maintenance_type": "CLEANING",
    "next_due": "2025-11-25"
  }]
}
```

---

### USER 6: SUPERVISOR - Maintenance Cost Tracking (Budget, Category, Vendor Payment)

**User:** Supervisor 2  
**Email:** supervisor2@hostel.com  
**Password:** super123  
**Feature:** Maintenance Cost Tracking APIs

#### Step 1: Login
**POST** `/auth/login`
```json
Request: {"email": "supervisor2@hostel.com", "password": "super123"}
Response: {"access_token": "eyJ...", "expires_in": 3600}
```

#### Step 2: Add Maintenance Cost
**POST** `/supervisor/maintenance/costs`  
**Headers:** `Authorization: Bearer <token>`
```json
Request: {
  "maintenance_request_id": 12,
  "category": "LABOR",
  "vendor_name": "ABC Plumbing",
  "description": "Pipe replacement",
  "amount": 750.00,
  "invoice_url": "https://example.com/invoice.pdf",
  "payment_method": "BANK_TRANSFER"
}
Response: {"id": 18, "message": "Cost recorded successfully"}
```

#### Step 3: Get Budget Summary by Category
**GET** `/supervisor/maintenance/budget/summary?start_date=2025-11-01&end_date=2025-11-30`  
**Headers:** `Authorization: Bearer <token>`
```json
Response: {
  "total_spent": 15750.00,
  "pending_payments": 2500.00,
  "paid_amount": 13250.00,
  "category_breakdown": {
    "PLUMBING": 5500.00,
    "ELECTRICAL": 4200.00,
    "CARPENTRY": 3050.00
  }
}
```


---

### USER 7: SUPERVISOR - Maintenance Task Assignment (Assign Staff, Track Progress, Quality Checks)

**User:** Supervisor 3  
**Email:** supervisor3@hostel.com  
**Password:** super123  
**Feature:** Maintenance Task Assignment

#### Step 1: Login
**POST** `/auth/login`
```json
Request: {"email": "supervisor3@hostel.com", "password": "super123"}
Response: {"access_token": "eyJ...", "expires_in": 3600}
```

#### Step 2: Create and Assign Task to Staff
**POST** `/supervisor/maintenance/tasks`  
**Headers:** `Authorization: Bearer <token>`
```json
Request: {
  "maintenance_request_id": 12,
  "assigned_to_id": 10,
  "task_title": "Fix leaking pipe",
  "task_description": "Replace damaged pipe section",
  "priority": "HIGH",
  "estimated_hours": 4,
  "scheduled_date": "2025-11-20"
}
Response: {"id": 8, "message": "Task assigned successfully"}
```

#### Step 3: Update Task with Completion & Quality Check
**PUT** `/supervisor/maintenance/tasks/8`  
**Headers:** `Authorization: Bearer <token>`
```json
Request: {
  "status": "COMPLETED",
  "completed_date": "2025-11-20",
  "actual_hours": 3.5,
  "quality_rating": 5,
  "completion_notes": "Work completed successfully, tested for leaks"ng
 TestiReady for** Status:)  
**OK0 ccessful (20 ✅ Su**es:espons 
**All Rs:** 50+ llAPI Cal 15  
**Totaal Users:** ot 
**Tents iremm Requs from SysteegorieCatature zed By:** Fegani
**Or2025  er 18, d:** Novembeate Cr
**Document


---ackinglance treave balows
- ✅ L workfpprovalor avis✅ Supers
- e requesttudent leav ✅ Sgregation
- rating agel
- ✅ Hostration ✅ Modevoting
-lpful 
- ✅ Hengsews and ratievi Student r ✅king
-ion tracecutisor exervnt
- ✅ Supmanagemealendar ✅ Csk setup
- ing ta✅ Recurr
-  Featuresed# Advanc
##irs
repaceeding hold-exthresor proval fmin ap
- ✅ Adssion submirequestpervisor 
- ✅ Su checksQualitytion
- ✅ on verificati
- ✅ ComplerogressTrack pndors
- ✅ aff/ven to stssigment
- ✅ Amanager payment 
- ✅ Vendory by categoost trackingel
- ✅ Cper hostlocation  ✅ Budget al tracking
-leent lifecyc
- ✅ Equipmring tasksurhedule recnt
- ✅ Sc assignmeg
- ✅ Staffatus trackin stty and ✅ Prioriorization
-ith categs wrequest ✅ Log t
-anagemenintenance M

### Maulationslcrating cagate  ✅ Aggrecy/rating
-y recen b ✅ Sortting
-✅ Helpful votection
- - ✅ Spam de/rejection
val approAdmin
- ✅ hotosh p wittars)ings (1-5 sit ratm
- ✅ Subms Syste Ratingviews &
### ReCKLIST
ESTING CHE--

## T

-visor)nt (Supere Manageme* Attendanc**User 15:*
- dent)Viewing (Stuce :** Attendaner 14- **Usn)
per Admierview (Su Ovtemys** S**User 13:S
-  FEATUREONAL ✅ ADDITI##rvisor)

#flow (Supe Workovale Appr:** Leav- **User 12(Student)
cation  Leave Appliser 11:** **Uin)
-ler (Admedunce Sch Maintenaventiver 9:** PreES
- **UseFEATURVANCED 
### ✅ AD
Admin)val (Approue Repair * High-Valr 8:*- **User)
upervisont (Ssignmek Asntenance Tasai** MUser 7:- **upervisor)
ng (STrackienance Cost Maintser 6:** 
- **UAPIs (Admin)intenance  MaeventivePr:**  5*Userrvisor)
- *PIs (Supeest Anance Requ4:** Mainte- **User NAGEMENT
CE MA✅ MAINTENANt)

### stem (StudenReview Sy* Advanced  **User 10:*sitor)
- (Ving & Sortiayw Displ Revieser 3:***Umin)
- *ation (AdModer Review r 2:**nt)
- **UseStudeon ( Submissi 1:** Review*UserEM
- *INGS SYSTRAT REVIEWS &  ✅##

#ARYSUMMURE MAPPING 

## FEAT

---
}
```ENT"}
  ]: "PRESus""stat, 25-11-18""20date":  "7,d": "student_i43,  {"id": 1T"},
   : "PRESENtatus"", "s-18 "2025-11e":": 6, "dattudent_id, "s144": 
    {"idENT"},RESs": "P, "statu-18"-11": "2025ate": 5, "dt_id "studen5,: 14""id
    {e": [ttendanc {
  "asponse:```json
Re<token>`
earer n: Biothorizatrs:** `Au`  
**Heade-18115-=202ate_d1-01&end5-1=202_datertport?stae/rendancsor/attevi* `/superET*port
**G Re Attendancetep 3: Get

#### S6}
```ed_count": rktrue, "ma: {"ok": onseResp"
}
 "PRESENTatus":",
  "st1-18"2025-1e": dance_dat
  "atten 10],7, 8, 9,, 6, ": [5idsdent_{
  "stu
Request: `json
```er <token>on: Bearthorizati `Auers:**k`  
**Head-marce/bulkattendanr/ `/supervisoce
**POST** Attendank Marktep 2: Bul### S
```

#_in": 3600} "expires...",": "eyJ_tokencesse: {"ac}
Responsper123"word": "suass.com", "pisor1@hostel "supervmail":equest: {"eon
Rogin`
```js** `/auth/l*POST
*in Log Step 1:)

####Operations(Supervisor ment nce Managettenda:** Aature**Feper123  
ord:** su 
**Passwostel.com upervisor1@h:** s
**Emailr 1  * SupervisoUser:***ment

e Managetendanc AtISOR -5: SUPERV# USER 1
---

##

}
```"}
  ]ESENT: "PR, "status"-11-15"025"2date":  "d": 75,    {"iNT"},
"ABSE":  "status11-16", "2025-te":"dad": 76, 
    {"i"},SENT": "PREatus", "st5-11-17ate": "202 77, "d    {"id":"},
PRESENT": ""status8", 025-11-1te": "2": 78, "da    {"id [
ttendance":  "anse: {
son
Respooken>`
```j Bearer <tization:or `Auth:****Headers`  
-11-18te=2025nd_da1&e25-11-0e=20rt_datl_id=1&sta?hostence/myttendatudent/aGET** `/sds
**orec Rendanceet My AttStep 2: G## }
```

##600: 3ires_in"..", "exp"eyJ.ss_token": "acce{
Response: "}t123 "studend":or"passwl.com", 4@hostenttude: "smail"uest: {"e``json
Req
`th/login`ST** `/aun
**PO 1: Logiep

#### Stiew)(Student Vanagement ttendance Mture:** A*Feat123  
*rd:** studen*Passwom  
*ostel.costudent4@hail:** nt 4  
**Emude* St**User:*Viewing

 Attendance UDENT - 14: STUSER-

### 

-- 3}
}
```ding":"pental": 13, "to {ts":e_requeseav  "l 3
  },
s":ng_complaint    "pendi 18,
nts":mplaital_coto"": 5,
    equests"pending_r,
    sts": 32eque   "total_rance": {
   "mainten": 7},
ing46, "pend"total": ws": {vie  },
  "re
    }
or": 25, "visit 1":student   ": 4,
   visor"3, "super: "admin"admin": 1, "super_{
      ":   "by_role
  ": 25,al   "tot": {
 users  "al": 4},
": {"totostels"hponse: {
  ```json
Res`
<token>: Bearer ationthorizs:** `Au  
**Header/overview`csdmin/analyti* `/super-acs
**GET*tialytem AnSys: Get # Step 2
```

###n": 3600}res_i..", "expi "eyJ.":s_token"accesonse: {"}
Respdmin123"a": sword", "pas.comhostel"admin@"email": : {stjson
Reque/login`
```T** `/auth**POSn
tep 1: Logi### Sent

# Managemdeystem-Wi* Sre:*
**Featun123  * admiPassword:*com  
**ostel.min@hil:** ad 
**Emaper Admin ser:** Su

**Uyticsew & Analystem Overvi SN -SUPER ADMISER 13: ## U

#IONAL USERS: ADDIT SECTION 4

##``

---ue}
`{"ok": tronse: sp
ReD"} "APPROVEstatus":: {"uest
Reqson
```j <token>`: Bearerationizs:** `Authorder**Heaiew`  
18/revts/leave/reques/supervisor/ `T**quest
**PU Reove Leavepr 3: ApStep#### 
```


}
  }]"PENDING"atus":    "st",
 remonyding ceFamily wedreason": ",
    "11-30"": "2025-"end_date,
    -25"11025-ate": "2"start_d
    t_id": 7,en
    "stud18,":     "id": [{
equests"r{
  Response: 
```json
er <token>`n: Bearrizatio`Authoders:** **Hea`  
NDINGstatus=PEests?r/leave/requ`/supervisoGET** Requests
**ding Leave p 2: Get Pen Ste

####0}
```es_in": 360ir.", "exp: "eyJ..cess_token"ponse: {"ac123"}
Res"superrd":  "passwocom",hostel.or1@"supervismail": {"e
Request: onogin`
```jsth/l`/auOST** *Pogin
*ep 1: L
#### St
visor Side)erent (Suption Managemave Applica Lee:**eatur**F
uper123  d:** s
**Passwor.com  tel1@hossupervisorail:**   
**Emsor 1ervi Supser:**

**U Workflowaleave ApprovPERVISOR - L SUR 12:USE
### 
---

025
}
```"year": 21,
  : s"uestng_req
  "pendidays": 18,maining_
  "re": 12,_days  "useds": 30,
 "total_day
 esponse: {
Rn>`
```jsonrer <tokeBeaization: hors:** `Aut  
**Headerance`/baleave/student/l `
**GET**anceBalLeave Check  Step 3: 
```

####} {"id": 18Response:y"
}
ceremony wedding ilson": "Famea  "r",
-11-30nd": "2025"e11-25",
  "2025-t": 
  "staruest: {`json
Req`
``arer <token>ization: Be`Authoraders:** =1`  
**Hely?hostel_ideave/appt/l* `/studenst
**POST*eave Requet Lep 2: Submi

#### St`}
``3600n": _i"expires", "eyJ...token": s_e: {"accesRespons"}
ent123: "studd""passworl.com", udent3@hostestail": ""emquest: {```json
Relogin`
auth/*POST** `/ 1: Login
*### Stepement

#anagation MLeave Appliceature:** 123  
**Fdent:** stu
**Passwordstel.com  hoent3@** stud 
**Email:dent 3  Stu

**User:**acking)Tral, Balance rovor App, Supervisston (Reque ApplicativeeaUDENT - L: ST# USER 11
##

---
 }
}
```7
 tar": 1: 16, "5_s"4_star"  8,
  3_star": : 3, "_star"ar": 2, "2_st"1
    : {on"g_distributiin "rat,
 46w_count": ie "rev: 4.2,
 g_rating""avstel",
   Ho"Sunrise"name": ": 1,
    "idonse: {
on
Resp`jss/1`
``ostelvisitor/h
**GET** `/regation Aggstel Ratingck Hoep 4: Che St##```

##": 14}
ntlpful_coutrue, "he: ok"e: {"ponses
```json
R<token>`n: Bearer thorizatioaders:** `Auful`  
**He/helpiews/25udent/rev`/st**POST** s Helpful
ew aAnother Reviark p 3: Mte

#### S
```rue
}pproved": tauto_a",
  "pproveditted and abmview su: "Re"gessa
  "meid": 26,": {
  ponse
Resnull
}: l"  "photo_ur",
be better.iFi could ties. Wli decent faciithd hostel w": "Gooxt"te
   4,"rating":st: {
  queson
Re
```joken>`: Bearer <tationiz* `Authorrs:*Heade1`  
**views/t/re* `/studen**POST*Rating
 with iewit Rev: Subm### Step 20}
```

#": 360s_in, "expireyJ..."token": "e"access_nse: {espot123"}
R: "studenrd", "passwotel.com"@hos"student2"email": st: {que
Re`jsonn`
``ogiauth/l
**POST** `/: LoginStep 1

#### )em (Advancedating Syst& R** Review 
**Feature: udent123 d:** stasswor**Pom  
tel.cnt2@hosstude:** mail
**E   2** Studenter:*Us)

*Moderation, lpful VotingSubmit, Hetem (ting Sys & RaiewENT - Rev 10: STUD

### USER
---rue}
```
k": tsponse: {"o.00
}
Re": 200cost"  ",
ems normalsystd, all pecte heater insWater": "
  "notes",-01 "2026-05ed_date": "complet",
 TED "COMPLE"status":{
  t: quesn
Re`
```jsoen>arer <tokrization: Be`Autho*Headers:** 2`  
*ce/tasks/1e-maintenanventiv`/admin/prePUT** 
**ionor Executrvispe Track Sup 4:

#### Ste`2}
``"id": 1 {onse:Resp05-01"
}
: "2026-_date"heduled  "sco_id": 4,
ed_t
  "assign 5,hedule_id": {
  "scon
Request:>`
```jsen<tokrer zation: Bea:** `Authori
**Headersce/tasks`  antenainventive-mmin/pread
**POST** `/Executionupervisor sk for Seate Tap 3: Crte
#### S
```
"id": 5}Response: {
-05-01"
}2026ue": "xt_d180,
  "nedays": cy_en"frequ
  CTION",INSPE: ""typetenance_in
  "maHEATER",ATER_ "Wt_type":  "equipmen 1,
":hostel_id  "{
quest: Re`
```json
oken>rer <ttion: Bea`Authorizas:** er  
**Headchedules`enance/stive-maintadmin/preven `/OST**e
**Pk Schedulring TasCreate Recur 2: Step

#### }
```s_in": 3600", "expire"eyJ...en": ccess_tokse: {"a"}
Respon"admin123ssword": ", "pacomel.host"admin1@{"email": quest: son
Rein`
```jth/log** `/au**POSTogin
## Step 1: L
##Scheduler
Maintenance entive re:** Preveatu3  
**Fn12** admid:*Passwor
*.com  steldmin1@hol:** a
**Emai Admin 1  r:**

**Useng)tion Tracki, Execuup, Calendarcurring Setduler (Recheintenance Sreventive Ma9: ADMIN - P## USER 

#SFEATURECED 3: ADVAN SECTION 
---

##"}
```
dpproveatus": "ast: true, "ok"{"Response: issue"
}
ty itical safe- Cr"Approved reason": true,
  "ed": "approvst: {
  json
Reque`
```r <token>ion: Bearehorizats:** `Auteread
**H  s/8/approve`uestenance/req/admin/maintt
**PUT** `ue Requesgh-Valprove Hi 3: Ap# Step``

### }]
}
`:30:00Z"
 1112T5-11-202 "t":d_a"create,
    d": falseoveppr"a0,
    st": 5000.0t_co "es",
   l rewiringricaplete elect"Comn": tioescrip
    "d",IGH": "Hority   "pri",
 ELECTRICALy": "  "categor": 2,
  tel_idhos  "  ": 8,

    "idsts": [{value_requehigh_
  "e: {on
Respons``jsn>`
`arer <tokeBerization: ho** `Auteaders:**H
hold=1000`  ?threshigh-valuequests/ntenance/redmin/maiET** `/ang)
**Gold Exceedits (ThreshValue Requesh-Higt tep 2: Ge#### S``

": 3600}
`expires_inJ...", "ken": "ey"access_tose: {espon"}
Rmin123adrd": "sswoom", "pa@hostel.c "admin2{"email":
Request: ```json`
auth/login* `/T*
**POSgin: Lo Step 1rs

####-Value Repaiw for HighkfloApproval Worature:** n123  
**Fe* admi*Password:*  
*hostel.comadmin2@
**Email:**   Admin 2 User:**val)

** Appron, Adminissiosor Submervial (Supepair Approvalue RIN - High-V ADMUSER 8:## 

#
```

---k": true}"onse: {po
}
Res