# API Endpoints - Parameters & Success Responses

## REVIEWS & RATINGS SYSTEM

### 1. Review Submission APIs - Submit ratings (1-5 stars), write reviews, upload photos

**POST /student/reviews/{hostel_id}**

Parameters:
```json
{
  "rating": 4,
  "text": "Great hostel with excellent facilities",
  "photo_url": "https://example.com/photo.jpg"
}
```

Success Response (200):
```json
{
  "id": 15,
  "message": "Review submitted and approved",
  "auto_approved": true
}
```

---

### 2. Review Moderation APIs - Admin review approval/rejection, spam detection, inappropriate content filtering

**GET /admin/reviews**

Parameters:
- Query: `status=pending`, `hostel_id=1`, `is_spam=false`
- Headers: `Authorization: Bearer <token>`

Success Response (200):
```json
{
  "reviews": [
    {
      "id": 15,
      "hostel_id": 1,
      "student_id": 5,
      "rating": 4,
      "text": "Great hostel with excellent facilities",
      "is_approved": false,
      "is_spam": false,
      "created_at": "2025-11-10T08:30:00Z"
    }
  ]
}
```

**PUT /admin/reviews/{review_id}/moderate**

Parameters:
- Path: `review_id=15`
- Query: `action=approve`
- Headers: `Authorization: Bearer <token>`

Success Response (200):
```json
{
  "ok": true,
  "action": "approve"
}
```

---

### 3. Review Display & Sorting APIs - Display reviews with helpful voting, sort by recency/rating, aggregate rating calculations

**GET /visitor/hostels/{hostel_id}/reviews**

Parameters:
- Path: `hostel_id=1`
- Query: `sort_by=newest`, `rating_filter=4`, `skip=0`, `limit=20`

Success Response (200):
```json
{
  "reviews": [
    {
      "id": 15,
      "rating": 4,
      "text": "Great hostel with excellent facilities",
      "photo_url": "https://example.com/photo.jpg",
      "helpful_count": 3,
      "created_at": "2025-11-10T08:30:00Z"
    }
  ]
}
```

**POST /student/reviews/{review_id}/helpful**

Parameters:
- Path: `review_id=15`
- Headers: `Authorization: Bearer <token>`

Success Response (200):
```json
{
  "ok": true,
  "helpful_count": 4
}
```

**GET /visitor/hostels/{hostel_id}**

Parameters:
- Path: `hostel_id=1`

Success Response (200):
```json
{
  "id": 1,
  "name": "Sunrise Hostel",
  "avg_rating": 4.2,
  "review_count": 45,
  "rating_distribution": {
    "1_star": 2,
    "2_star": 3,
    "3_star": 8,
    "4_star": 15,
    "5_star": 17
  }
}
```

---

## MAINTENANCE MANAGEMENT

### 4. Maintenance Request APIs - Log maintenance requests with categorization, priority, status tracking, staff assignment

**POST /supervisor/maintenance/requests**

Parameters:
```json
{
  "category": "PLUMBING",
  "priority": "HIGH",
  "description": "Leaking pipe in room 101",
  "photo_url": "https://example.com/leak.jpg",
  "est_cost": 500.00,
  "scheduled_date": "2025-11-12"
}
```

Success Response (200):
```json
{
  "id": 5,
  "message": "Request created and approved",
  "requires_approval": false
}
```

**GET /admin/maintenance/requests**

Parameters:
- Query: `hostel_id=1`, `status=PENDING`, `category=PLUMBING`, `priority=HIGH`
- Headers: `Authorization: Bearer <token>`

Success Response (200):
```json
{
  "requests": [
    {
      "id": 5,
      "hostel_id": 1,
      "category": "PLUMBING",
      "priority": "HIGH",
      "status": "PENDING",
      "description": "Leaking pipe in room 101",
      "est_cost": 500.00,
      "assigned_to_id": null,
      "created_at": "2025-11-10T10:30:00Z"
    }
  ]
}
```

**PUT /admin/maintenance/requests/{request_id}/assign**

Parameters:
- Path: `request_id=5`
- Body: `{"assigned_to_id": 10, "scheduled_date": "2025-11-12"}`
- Headers: `Authorization: Bearer <token>`

Success Response (200):
```json
{
  "ok": true,
  "message": "Request assigned to John Smith"
}
```

---

### 5. Preventive Maintenance APIs - Schedule recurring maintenance tasks, maintenance calendar, equipment lifecycle tracking

**POST /admin/preventive-maintenance/schedules**

Parameters:
```json
{
  "hostel_id": 1,
  "equipment_type": "AC_UNIT",
  "maintenance_type": "CLEANING",
  "frequency_days": 90,
  "next_due": "2025-12-01"
}
```

Success Response (200):
```json
{
  "id": 3
}
```

**GET /admin/preventive-maintenance/schedules**

Parameters:
- Query: `hostel_id=1`
- Headers: `Authorization: Bearer <token>`

Success Response (200):
```json
{
  "schedules": [
    {
      "id": 3,
      "hostel_id": 1,
      "equipment_type": "AC_UNIT",
      "maintenance_type": "CLEANING",
      "frequency_days": 90,
      "next_due": "2025-12-01",
      "last_maintenance": "2025-09-01"
    }
  ]
}
```

**GET /admin/preventive-maintenance/due**

Parameters:
- Query: `days_ahead=7`, `hostel_id=1`
- Headers: `Authorization: Bearer <token>`

Success Response (200):
```json
{
  "due_schedules": [
    {
      "id": 3,
      "hostel_id": 1,
      "equipment_type": "AC_UNIT",
      "maintenance_type": "CLEANING",
      "next_due": "2025-11-15"
    }
  ]
}
```

---

### 6. Maintenance Cost Tracking APIs - Budget allocation per hostel, cost tracking by category, vendor payment management

**POST /supervisor/maintenance/costs**

Parameters:
```json
{
  "maintenance_request_id": 5,
  "category": "PLUMBING",
  "vendor_name": "ABC Plumbing Services",
  "description": "Pipe replacement and labor",
  "amount": 750.00,
  "invoice_url": "https://example.com/invoice.pdf",
  "payment_method": "BANK_TRANSFER"
}
```

Success Response (200):
```json
{
  "id": 8,
  "message": "Cost recorded successfully"
}
```

**GET /supervisor/maintenance/costs**

Parameters:
- Query: `hostel_id=1`, `category=PLUMBING`, `payment_status=PENDING`
- Headers: `Authorization: Bearer <token>`

Success Response (200):
```json
{
  "costs": [
    {
      "id": 8,
      "maintenance_request_id": 5,
      "category": "PLUMBING",
      "vendor_name": "ABC Plumbing Services",
      "amount": 750.00,
      "payment_status": "PENDING",
      "created_at": "2025-11-10T14:30:00Z"
    }
  ]
}
```

**GET /supervisor/maintenance/budget/summary**

Parameters:
- Query: `category=PLUMBING`, `start_date=2025-11-01`, `end_date=2025-11-30`
- Headers: `Authorization: Bearer <token>`

Success Response (200):
```json
{
  "total_spent": 15750.00,
  "pending_payments": 2500.00,
  "paid_amount": 13250.00,
  "category_breakdown": {
    "PLUMBING": 5500.00,
    "ELECTRICAL": 4200.00,
    "CARPENTRY": 3050.00,
    "PAINTING": 2000.00,
    "OTHER": 1000.00
  }
}
```

---

### 7. Maintenance Task Assignment - Assign to staff/vendors, track progress, completion verification, quality checks

**POST /supervisor/maintenance/tasks**

Parameters:
```json
{
  "maintenance_request_id": 5,
  "assigned_to_id": 10,
  "task_title": "Fix leaking pipe",
  "task_description": "Replace damaged pipe section",
  "priority": "HIGH",
  "estimated_hours": 4,
  "scheduled_date": "2025-11-12"
}
```

Success Response (200):
```json
{
  "id": 12,
  "message": "Task assigned successfully"
}
```

**GET /supervisor/maintenance/tasks**

Parameters:
- Query: `status=IN_PROGRESS`, `assigned_to_id=10`
- Headers: `Authorization: Bearer <token>`

Success Response (200):
```json
{
  "tasks": [
    {
      "id": 12,
      "maintenance_request_id": 5,
      "assigned_to_id": 10,
      "task_title": "Fix leaking pipe",
      "status": "IN_PROGRESS",
      "priority": "HIGH",
      "estimated_hours": 4,
      "actual_hours": null,
      "quality_rating": null,
      "scheduled_date": "2025-11-12"
    }
  ]
}
```

**PUT /supervisor/maintenance/tasks/{task_id}**

Parameters:
- Path: `task_id=12`
- Body: `{"status": "COMPLETED", "completed_date": "2025-11-12", "actual_hours": 3.5, "quality_rating": 5, "completion_notes": "Work completed successfully"}`
- Headers: `Authorization: Bearer <token>`

Success Response (200):
```json
{
  "ok": true
}
```

---

### 8. Approval Workflow for High-Value Repairs - Supervisor request submission, admin approval for threshold-exceeding repairs

**GET /admin/maintenance/requests/high-value**

Parameters:
- Query: `threshold=1000`, `skip=0`, `limit=50`
- Headers: `Authorization: Bearer <token>`

Success Response (200):
```json
{
  "high_value_requests": [
    {
      "id": 5,
      "hostel_id": 1,
      "category": "PLUMBING",
      "priority": "HIGH",
      "description": "Complete bathroom renovation",
      "est_cost": 5000.00,
      "approved": false,
      "created_at": "2025-11-10T10:30:00Z"
    }
  ]
}
```

**PUT /admin/maintenance/requests/{request_id}/approve**

Parameters:
- Path: `request_id=5`
- Body: `{"approved": true, "reason": "Approved for repair"}`
- Headers: `Authorization: Bearer <token>`

Success Response (200):
```json
{
  "ok": true,
  "status": "approved"
}
```

---

## ADVANCED FEATURES

### 9. Preventive Maintenance Scheduler - Recurring task setup, calendar management, supervisor execution tracking

**POST /admin/preventive-maintenance/tasks**

Parameters:
```json
{
  "schedule_id": 3,
  "assigned_to_id": 10,
  "scheduled_date": "2025-12-01"
}
```

Success Response (200):
```json
{
  "id": 15
}
```

**PUT /admin/preventive-maintenance/tasks/{task_id}**

Parameters:
- Path: `task_id=15`
- Body: `{"status": "COMPLETED", "completed_date": "2025-12-01", "notes": "AC cleaning completed", "cost": 200.00}`
- Headers: `Authorization: Bearer <token>`

Success Response (200):
```json
{
  "ok": true
}
```

---

### 10. Review & Rating System - Student reviews, ratings, helpful voting, moderation, hostel rating aggregation

**GET /admin/reviews/analytics**

Parameters:
- Query: `hostel_id=1`, `days=30`
- Headers: `Authorization: Bearer <token>`

Success Response (200):
```json
{
  "period_days": 30,
  "total_reviews": 45,
  "approved_reviews": 32,
  "pending_reviews": 8,
  "spam_reviews": 5,
  "avg_rating": 4.2,
  "rating_distribution": {
    "1_star": 2,
    "2_star": 3,
    "3_star": 8,
    "4_star": 15,
    "5_star": 17
  },
  "approval_rate": 71.11
}
```

---

### 11. Leave Application Management - Student leave requests, supervisor approval workflows, leave balance tracking

**POST /student/leave/apply**

Parameters:
- Query: `hostel_id=1`
- Body:
```json
{
  "start": "2025-11-15",
  "end": "2025-11-20",
  "reason": "Family wedding ceremony"
}
```

Success Response (200):
```json
{
  "id": 8
}
```

**GET /student/leave/balance**

Parameters:
- Headers: `Authorization: Bearer <token>`

Success Response (200):
```json
{
  "total_days": 30,
  "used_days": 12,
  "remaining_days": 18,
  "pending_requests": 2,
  "year": 2025
}
```

**GET /supervisor/leave/requests**

Parameters:
- Query: `status=PENDING`
- Headers: `Authorization: Bearer <token>`

Success Response (200):
```json
{
  "requests": [
    {
      "id": 8,
      "student_id": 5,
      "start_date": "2025-11-15",
      "end_date": "2025-11-20",
      "reason": "Family wedding ceremony",
      "status": "PENDING"
    }
  ]
}
```

**PUT /supervisor/leave/requests/{request_id}/review**

Parameters:
- Path: `request_id=8`
- Body: `{"status": "APPROVED"}`
- Headers: `Authorization: Bearer <token>`

Success Response (200):
```json
{
  "ok": true
}
```
